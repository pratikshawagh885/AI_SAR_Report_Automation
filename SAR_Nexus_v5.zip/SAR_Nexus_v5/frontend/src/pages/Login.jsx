import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login, register } = useAuth();
  const nav = useNavigate();

  // 'admin-login' | 'user-login' | 'register'
  const [mode,     setMode]     = useState('user-login');
  const [email,    setEmail]    = useState('');
  const [pass,     setPass]     = useState('');
  const [name,     setName]     = useState('');
  const [phone,    setPhone]    = useState('');
  const [confirm,  setConfirm]  = useState('');
  const [showP,    setShowP]    = useState(false);
  const [err,      setErr]      = useState('');
  const [busy,     setBusy]     = useState(false);

  const isAdmin    = mode === 'admin-login';
  const isRegister = mode === 'register';
  const accent     = isAdmin ? '#4f6ef7' : '#22c55e';

  const switchMode = (m) => {
    setMode(m); setErr('');
    setEmail(''); setPass(''); setName(''); setPhone(''); setConfirm('');
    if (m === 'admin-login') { setEmail('admin@sar.io'); setPass('admin123'); }
  };

  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true);
    await new Promise(r => setTimeout(r, 700));
    try {
      if (isRegister) {
        if (!name.trim()) throw new Error('Full name is required');
        if (pass !== confirm) throw new Error('Passwords do not match');
        const u = register({ name, email, pass, phone });
        nav('/user-dashboard');
      } else {
        const u = login(email, pass);
        nav(u.role === 'user' ? '/user-dashboard' : '/admin');
      }
    } catch(ex) { setErr(ex.message); }
    setBusy(false);
  };

  return (
    <div style={{minHeight:'100vh',background:'#080b12',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'DM Sans',sans-serif",padding:'1.5rem',position:'relative',overflow:'hidden'}}>
      {/* Glows */}
      <div style={{position:'absolute',top:'-15%',left:'-10%',width:500,height:500,background:`radial-gradient(circle,${accent}15 0%,transparent 70%)`,pointerEvents:'none',transition:'background .4s'}}/>
      <div style={{position:'absolute',bottom:'-15%',right:'-10%',width:400,height:400,background:`radial-gradient(circle,${accent}0d 0%,transparent 70%)`,pointerEvents:'none',transition:'background .4s'}}/>

      <div style={{width:'100%',maxWidth:440}}>

        {/* Logo */}
        <div style={{textAlign:'center',marginBottom:'1.75rem'}}>
          <div style={{width:54,height:54,background:`linear-gradient(135deg,${accent},${accent}bb)`,borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',fontSize:24,margin:'0 auto 0.9rem',boxShadow:`0 0 32px ${accent}50`,transition:'all .4s'}}>⚡</div>
          <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:22,fontWeight:700,color:'#fff',margin:0}}>SAR Nexus</h1>
          <p style={{fontSize:12,color:'#334155',margin:'4px 0 0'}}>AI-Powered Compliance & Banking Platform</p>
        </div>

        {/* Mode tabs */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6,marginBottom:'1.5rem',background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:14,padding:5}}>
          {[
            ['user-login',  '💳', 'Sign In',  '#22c55e'],
            ['register',    '✨', 'Register', '#22c55e'],
            ['admin-login', '🛡️', 'Admin',    '#4f6ef7'],
          ].map(([m, ic, label, col])=>(
            <button key={m} onClick={()=>switchMode(m)}
              style={{padding:'10px 6px',borderRadius:10,border:`1px solid ${mode===m?col+'55':'transparent'}`,background:mode===m?`${col}14`:'transparent',cursor:'pointer',textAlign:'center',transition:'all .2s'}}>
              <div style={{fontSize:18,marginBottom:3}}>{ic}</div>
              <div style={{fontSize:11,fontWeight:700,color:mode===m?col:'#475569',transition:'color .2s'}}>{label}</div>
            </button>
          ))}
        </div>

        {/* Form card */}
        <div style={{background:'#0d1018',border:`1px solid ${accent}22`,borderRadius:18,padding:'1.75rem',boxShadow:`0 20px 60px rgba(0,0,0,0.5)`,transition:'border-color .4s'}}>

          <div style={{fontSize:10,color:accent,fontWeight:700,letterSpacing:1,marginBottom:'1.25rem'}}>
            {isRegister ? 'CREATE YOUR ACCOUNT' : isAdmin ? 'ADMINISTRATOR SIGN IN' : 'USER SIGN IN'}
          </div>

          <form onSubmit={submit}>
            {/* Name — register only */}
            {isRegister && (
              <div style={{marginBottom:'1rem'}}>
                <label style={lbl}>FULL NAME *</label>
                <Inp value={name} onChange={setName} type="text" placeholder="e.g. John Smith" accent={accent}/>
              </div>
            )}

            {/* Email */}
            <div style={{marginBottom:'1rem'}}>
              <label style={lbl}>EMAIL *</label>
              <Inp value={email} onChange={setEmail} type="email" placeholder={isAdmin?"admin@sar.io":"your@email.com"} accent={accent}/>
            </div>

            {/* Phone — register only */}
            {isRegister && (
              <div style={{marginBottom:'1rem'}}>
                <label style={lbl}>PHONE (OPTIONAL)</label>
                <Inp value={phone} onChange={setPhone} type="tel" placeholder="+1-555-000-0000" accent={accent}/>
              </div>
            )}

            {/* Password */}
            <div style={{marginBottom: isRegister?'1rem':'1.5rem', position:'relative'}}>
              <label style={lbl}>PASSWORD *</label>
              <div style={{position:'relative'}}>
                <Inp value={pass} onChange={setPass} type={showP?'text':'password'} placeholder={isRegister?"Min 6 characters":"••••••••"} accent={accent}/>
                <button type="button" onClick={()=>setShowP(v=>!v)}
                  style={{position:'absolute',right:12,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',cursor:'pointer',color:'#475569',fontSize:14,padding:0}}>
                  {showP?'🙈':'👁'}
                </button>
              </div>
            </div>

            {/* Confirm password — register only */}
            {isRegister && (
              <div style={{marginBottom:'1.5rem'}}>
                <label style={lbl}>CONFIRM PASSWORD *</label>
                <Inp value={confirm} onChange={setConfirm} type="password" placeholder="Re-enter password" accent={accent}/>
              </div>
            )}

            {err && (
              <div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.3)',borderRadius:9,padding:'10px 14px',color:'#fca5a5',fontSize:12,marginBottom:'1rem',display:'flex',alignItems:'center',gap:8}}>
                ⚠ {err}
              </div>
            )}

            <button type="submit" disabled={busy}
              style={{width:'100%',background:busy?'#1a1f2e':`linear-gradient(135deg,${accent},${accent}cc)`,color:'#fff',border:'none',borderRadius:10,padding:13,fontSize:14,fontWeight:700,cursor:busy?'not-allowed':'pointer',transition:'all .25s',boxShadow:busy?'none':`0 4px 20px ${accent}44`,letterSpacing:0.3}}>
              {busy
                ? <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                    <span style={{width:13,height:13,border:'2px solid #ffffff44',borderTop:'2px solid #fff',borderRadius:'50%',display:'inline-block',animation:'spin .8s linear infinite'}}/>
                    {isRegister?'Creating account…':'Signing in…'}
                  </span>
                : isRegister ? 'Create Account →' : isAdmin ? 'Sign in as Admin →' : 'Sign in →'
              }
              <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            </button>
          </form>

          {/* Hints */}
          <div style={{marginTop:'1rem',padding:'10px 12px',background:`${accent}0a`,border:`1px solid ${accent}18`,borderRadius:9}}>
            {isAdmin && <div style={{fontSize:11,color:'#475569'}}>Demo — Email: <span style={{color:'#818cf8',fontFamily:'monospace'}}>admin@sar.io</span> · Pass: <span style={{color:'#818cf8',fontFamily:'monospace'}}>admin123</span></div>}
            {!isAdmin && !isRegister && <div style={{fontSize:11,color:'#475569'}}>Don't have an account? <button type="button" onClick={()=>switchMode('register')} style={{background:'none',border:'none',color:accent,cursor:'pointer',fontSize:11,fontWeight:700,padding:0}}>Register here →</button></div>}
            {isRegister && <div style={{fontSize:11,color:'#475569'}}>Already have an account? <button type="button" onClick={()=>switchMode('user-login')} style={{background:'none',border:'none',color:accent,cursor:'pointer',fontSize:11,fontWeight:700,padding:0}}>Sign in →</button></div>}
          </div>
        </div>

        <p style={{textAlign:'center',fontSize:10,color:'#1e2435',marginTop:'1.25rem'}}>🔒 256-bit encrypted · SOC 2 compliant · GDPR ready</p>
      </div>
    </div>
  );
}

// ── Shared sub-components ────────────────────────────────────────────────────
const lbl = { fontSize:10, color:'#64748b', fontWeight:700, letterSpacing:0.5, display:'block', marginBottom:5 };

function Inp({ value, onChange, type='text', placeholder, accent }) {
  const [f, setF] = useState(false);
  return (
    <input value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder} required={type!=='tel'}
      style={{width:'100%',background:'#080b12',border:`1px solid ${f?accent:accent+'28'}`,color:'#e2e8f0',borderRadius:9,padding:'11px 14px',fontSize:13,boxSizing:'border-box',outline:'none',fontFamily:"'DM Sans',sans-serif",transition:'border .15s'}}
      onFocus={()=>setF(true)} onBlur={()=>setF(false)}
    />
  );
}
