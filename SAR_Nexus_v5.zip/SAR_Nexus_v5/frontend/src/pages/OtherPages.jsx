import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { DB, ACCOUNTS, accountHistory, subscribe } from '../data/store';
import { useAuth } from '../context/AuthContext';
import { Card, RiskBadge, SBadge, Btn, Modal, PHdr, Toast, TArea, TInput, DataRow, riskColor } from '../components/UI';

const TT = { contentStyle:{background:'#1a1d27',border:'1px solid #3d4261',borderRadius:9,fontSize:11} };
const TX = { fill:'#475569',fontSize:11 };

// ════════════ ACCOUNT PROFILES ════════════════════════════════════════════════
export function Accounts() {
  const nav = useNavigate();
  const [sel, setSel] = useState(ACCOUNTS[0].id);
  const [, tick] = useState(0);

  useEffect(()=>subscribe(()=>tick(t=>t+1)),[]);

  const acc   = ACCOUNTS.find(a=>a.id===sel);
  const hist  = accountHistory(sel);
  const txns  = DB.transactions().filter(t=>t.accountId===sel);
  const sars  = DB.sars().filter(s=>s.accountId===sel);
  const avgDa = Math.round((acc?.avgMonthly||10000)/30);

  return (
    <div>
      <PHdr title="Account Profiles" sub="Select an account to view full transaction history, ML behaviour graph, and risk analysis"/>
      <div style={{display:'grid',gridTemplateColumns:'280px 1fr',gap:'1rem'}}>
        {/* Account list */}
        <div style={{display:'flex',flexDirection:'column',gap:'0.5rem'}}>
          {ACCOUNTS.map(a=>(
            <div key={a.id} onClick={()=>setSel(a.id)}
              style={{background:sel===a.id?'#1e2d4a':'#1a1d27',border:`1px solid ${sel===a.id?'#4f6ef7':'#2d3147'}`,borderRadius:12,padding:'0.85rem',cursor:'pointer',transition:'all .15s'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                <div>
                  <div style={{fontSize:13,fontWeight:600,color:'#e2e8f0'}}>{a.name}</div>
                  <div style={{fontSize:10,color:'#475569',marginTop:2}}>{a.id} · {a.type}</div>
                  <div style={{fontSize:10,color:'#475569'}}>{a.country}</div>
                </div>
                <div style={{display:'flex',flexDirection:'column',gap:3,alignItems:'flex-end'}}>
                  <SBadge status={a.riskLevel}/>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Account detail */}
        {acc && (
          <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
            {/* Header */}
            <Card>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:'0.5rem'}}>
                <div>
                  <h2 style={{fontFamily:"'Sora',sans-serif",fontSize:17,fontWeight:600,color:'#fff',margin:0}}>{acc.name}</h2>
                  <div style={{fontSize:12,color:'#64748b',marginTop:4}}>{acc.id} · {acc.type} · {acc.country}</div>
                </div>
                <SBadge status={acc.riskLevel}/>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'0.7rem',marginTop:'1rem'}}>
                <div style={{background:'#1e2535',borderRadius:9,padding:'0.7rem',textAlign:'center'}}>
                  <div style={{fontSize:11,color:'#64748b'}}>Monthly Avg</div>
                  <div style={{fontSize:16,fontWeight:700,color:'#fff',marginTop:3}}>${acc.avgMonthly.toLocaleString()}</div>
                </div>
                <div style={{background:'#1e2535',borderRadius:9,padding:'0.7rem',textAlign:'center'}}>
                  <div style={{fontSize:11,color:'#64748b'}}>Total Transactions</div>
                  <div style={{fontSize:16,fontWeight:700,color:'#fff',marginTop:3}}>{txns.length}</div>
                </div>
                <div style={{background:'#1e2535',borderRadius:9,padding:'0.7rem',textAlign:'center'}}>
                  <div style={{fontSize:11,color:'#64748b'}}>SAR Reports</div>
                  <div style={{fontSize:16,fontWeight:700,color:sars.length>0?'#ef4444':'#6ee7b7',marginTop:3}}>{sars.length}</div>
                </div>
              </div>
              <div style={{marginTop:'0.75rem',display:'grid',gridTemplateColumns:'1fr 1fr',gap:'0.5rem',fontSize:12}}>
                <DataRow label="Email"  value={acc.email}/>
                <DataRow label="Phone"  value={acc.phone}/>
              </div>
            </Card>

            {/* 12-month history graph */}
            <Card>
              <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:4}}>{acc.name} — 12-Month Transaction History</div>
              <div style={{fontSize:11,color:'#64748b',marginBottom:10}}>Daily average: ${avgDa.toLocaleString()} · Spikes may indicate suspicious activity</div>
              <ResponsiveContainer width="100%" height={190}>
                <BarChart data={hist}>
                  <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                  <YAxis tick={TX} axisLine={false} tickLine={false} tickFormatter={v=>'$'+Math.round(v/1000)+'k'}/>
                  <Tooltip {...TT} formatter={v=>'$'+v.toLocaleString()}/>
                  <Bar dataKey="amount" name="Monthly Total" radius={[3,3,0,0]}>
                    {hist.map((h,i)=>(
                      <Cell key={i} fill={h.amount>acc.avgMonthly*2?'#ef4444':h.amount>acc.avgMonthly*1.3?'#f59e0b':'#4f6ef7'}/>
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div style={{display:'flex',gap:'1rem',fontSize:11,color:'#64748b',marginTop:6}}>
                <span><span style={{color:'#ef4444'}}>■</span> 2× avg = suspicious spike</span>
                <span><span style={{color:'#f59e0b'}}>■</span> 1.3× avg = elevated</span>
                <span><span style={{color:'#4f6ef7'}}>■</span> Normal range</span>
              </div>
            </Card>

            {/* Transaction list for this account */}
            <Card style={{padding:0,overflow:'hidden'}}>
              <div style={{padding:'0.8rem 1rem',fontSize:12,fontWeight:500,color:'#e2e8f0',borderBottom:'1px solid #2d3147',display:'flex',justifyContent:'space-between'}}>
                <span>Transactions ({txns.length})</span>
                <Btn sm onClick={()=>nav('/transactions')}>View all →</Btn>
              </div>
              {txns.length===0
                ? <div style={{padding:'2rem',textAlign:'center',color:'#475569',fontSize:12}}>No transactions on record</div>
                : txns.map(t=>(
                  <div key={t.id} onClick={()=>nav(`/transactions/${t.id}`)}
                    style={{display:'flex',alignItems:'center',gap:'0.75rem',padding:'9px 1rem',borderBottom:'1px solid #1a1d27',cursor:'pointer',fontSize:12,transition:'background .1s'}}
                    onMouseEnter={e=>e.currentTarget.style.background='#1e2535'}
                    onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                    <span style={{color:'#818cf8',fontFamily:'monospace',minWidth:80}}>{t.id}</span>
                    <span style={{color:'#fff',fontWeight:600,minWidth:90}}>${t.amount.toLocaleString()}</span>
                    <span style={{color:'#64748b',flex:1}}>{t.type} · {t.country}</span>
                    <RiskBadge score={t.riskScore}/>
                    <SBadge status={t.status}/>
                  </div>
                ))
              }
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

// ════════════ WATCHLIST ════════════════════════════════════════════════════════
export function Watchlist() {
  const { can } = useAuth();
  const nav = useNavigate();
  const watchAcc = ACCOUNTS.filter(a=>a.riskLevel!=='low').sort((a,b)=>{
    const lvl = {high:3,medium:2,low:1};
    return lvl[b.riskLevel]-lvl[a.riskLevel];
  });

  return (
    <div>
      <PHdr title="Predictive Watchlist" sub="ML-ranked accounts most likely to generate SARs in the next 7–30 days"/>
      <div style={{display:'flex',flexDirection:'column',gap:'0.75rem'}}>
        {watchAcc.map((a,i)=>{
          const days = a.riskLevel==='high'?(i<2?7:14):21;
          const txnCount = DB.transactions().filter(t=>t.accountId===a.id).length;
          const sarCount = DB.sars().filter(s=>s.accountId===a.id).length;
          return (
            <Card key={a.id} style={{display:'flex',alignItems:'center',gap:'1rem'}}>
              <div style={{width:42,height:42,borderRadius:10,background:a.riskLevel==='high'?'rgba(239,68,68,.15)':'rgba(245,158,11,.15)',
                display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:18}}>
                {a.riskLevel==='high'?'🔴':'🟡'}
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
                  <span style={{fontSize:13,fontWeight:600,color:'#e2e8f0'}}>{a.name}</span>
                  <span style={{fontSize:10,fontFamily:'monospace',color:'#475569'}}>{a.id}</span>
                  <SBadge status={a.riskLevel}/>
                </div>
                <div style={{fontSize:11,color:'#64748b',marginTop:3}}>
                  {a.country} · {a.type} · {txnCount} transactions · {sarCount} SARs on file
                </div>
                <div style={{fontSize:11,color:riskColor(a.riskLevel==='high'?88:65),marginTop:2,fontWeight:600}}>
                  {a.riskLevel==='high' ? `⚠ SAR likely within ${days} days` : `👁 Monitor — review in ${days} days`}
                </div>
              </div>
              <div style={{display:'flex',gap:'0.4rem',flexShrink:0}}>
                <Btn sm ghost onClick={()=>nav('/accounts')}>Profile →</Btn>
                {can('createSAR') && a.riskLevel==='high' && (
                  <Btn sm color="#ef4444" onClick={()=>nav('/reports')}>SAR Reports</Btn>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ════════════ BLOCKCHAIN ══════════════════════════════════════════════════════
export function Blockchain() {
  const [verify, setVerify] = useState('');
  const [result, setResult] = useState(null);
  const [, tick] = useState(0);

  useEffect(()=>subscribe(()=>tick(t=>t+1)),[]);
  const records = DB.blockchain();

  const doVerify = () => {
    if (!verify.trim()) return;
    const found = records.find(r=>r.txHash.includes(verify.trim())||r.sarId.includes(verify.trim()));
    setResult(found?{ok:true,rec:found}:{ok:false});
  };

  return (
    <div>
      <PHdr title="Blockchain Audit Trail" sub="Every filed SAR cryptographically recorded on Ethereum — tamper-proof and publicly verifiable"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'0.8rem',marginBottom:'1rem'}}>
        {[
          {l:'Records On-Chain', v:String(records.length),       i:'⛓'},
          {l:'Network',          v:'Ethereum Sepolia',           i:'🌐'},
          {l:'Contract',         v:'0x4f2a...9c1b',             i:'📄'},
          {l:'Gas per SAR',      v:'~0.002 ETH',                i:'⛽'},
        ].map(c=>(
          <div key={c.l} style={{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:12,padding:'0.9rem'}}>
            <div style={{fontSize:20,marginBottom:5}}>{c.i}</div>
            <div style={{fontSize:11,color:'#64748b'}}>{c.l}</div>
            <div style={{fontSize:14,fontWeight:600,color:'#fff',fontFamily:'monospace',marginTop:3,overflow:'hidden',textOverflow:'ellipsis'}}>{c.v}</div>
          </div>
        ))}
      </div>

      {/* Verify tool */}
      <Card style={{marginBottom:'1rem'}}>
        <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:10}}>🔍 Verify a SAR Hash</div>
        <div style={{display:'flex',gap:'0.6rem'}}>
          <input value={verify} onChange={e=>{setVerify(e.target.value);setResult(null);}}
            placeholder="Paste a tx hash or SAR ID..."
            style={{flex:1,background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'9px 13px',fontSize:12,outline:'none'}}/>
          <Btn onClick={doVerify}>Verify On-Chain</Btn>
        </div>
        {result && (
          <div style={{marginTop:10,padding:'0.8rem',borderRadius:9,background:result.ok?'rgba(34,197,94,.1)':'rgba(239,68,68,.1)',border:`1px solid ${result.ok?'#166534':'#991b1b'}`,fontSize:12,color:result.ok?'#6ee7b7':'#fca5a5'}}>
            {result.ok
              ? `✅ Verified · SAR: ${result.rec.sarId} · Block #${result.rec.block} · Filed by: ${result.rec.filedBy} · ${new Date(result.rec.ts).toLocaleString()}`
              : '❌ Hash not found in blockchain records'}
          </div>
        )}
      </Card>

      {/* Records */}
      <Card style={{padding:0,overflow:'hidden'}}>
        <div style={{padding:'0.8rem 1rem',fontSize:12,fontWeight:500,color:'#e2e8f0',borderBottom:'1px solid #2d3147'}}>On-Chain Filing Records</div>
        {records.length===0
          ? <div style={{padding:'3rem',textAlign:'center',color:'#475569',fontSize:12}}>No records yet — approve a SAR and click "File On Blockchain" to create the first record</div>
          : records.map(r=>(
            <div key={r.txHash} style={{display:'flex',alignItems:'center',gap:'0.75rem',padding:'10px 1rem',borderBottom:'1px solid #1a1d27',fontSize:11}}>
              <span style={{width:8,height:8,borderRadius:'50%',background:'#22c55e',flexShrink:0,display:'inline-block'}}/>
              <span style={{fontFamily:'monospace',color:'#4f6ef7',minWidth:140,overflow:'hidden',textOverflow:'ellipsis'}}>{r.txHash}</span>
              <span style={{color:'#94a3b8',minWidth:100}}>{r.sarId}</span>
              <span style={{color:'#64748b',flex:1}}>{new Date(r.ts).toLocaleString()}</span>
              <span style={{fontFamily:'monospace',color:'#475569',minWidth:80}}>#{r.block}</span>
              <span style={{color:'#475569',minWidth:70}}>{r.gas}</span>
              <span style={{color:'#64748b',minWidth:70}}>{r.filedBy}</span>
            </div>
          ))
        }
      </Card>
    </div>
  );
}

// ════════════ AUDIT LOG ════════════════════════════════════════════════════════
export function AuditLog() {
  const { can } = useAuth();
  const [, tick] = useState(0);
  useEffect(()=>subscribe(()=>tick(t=>t+1)),[]);

  if (!can('auditLog')) return (
    <div style={{padding:'3rem',textAlign:'center'}}>
      <div style={{fontSize:40,marginBottom:12}}>⛔</div>
      <h2 style={{color:'#ef4444',fontFamily:"'Sora',sans-serif"}}>Access Denied</h2>
      <p style={{color:'#64748b',fontSize:13}}>Audit Log is restricted to Legal team and Admins.</p>
    </div>
  );

  const logs = DB.auditLog();
  const ACTION_ICON = { 'SAR Approved':'✅','SAR Rejected':'❌','SAR Filed On-Chain':'⛓','SAR Created':'📋','Transaction Added':'💳','Warning Issued':'⚠','Email Notice Sent':'📧','System started':'🔧' };

  return (
    <div>
      <PHdr title="Audit Log" sub={`${logs.length} actions recorded — every approval, rejection, warning and email is logged here`}/>
      <Card style={{padding:0,overflow:'hidden'}}>
        <div style={{padding:'0.8rem 1rem',fontSize:12,fontWeight:500,color:'#e2e8f0',borderBottom:'1px solid #2d3147',display:'flex',justifyContent:'space-between'}}>
          <span>Complete action history</span>
          <span style={{color:'#475569'}}>{logs.length} entries</span>
        </div>
        {logs.map((l,i)=>(
          <div key={i} style={{display:'flex',alignItems:'flex-start',gap:'1rem',padding:'10px 1rem',borderBottom:'1px solid #1a1d27',fontSize:12,transition:'background .1s'}}
            onMouseEnter={e=>e.currentTarget.style.background='#1e2535'}
            onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
            <span style={{fontSize:16,flexShrink:0}}>{ACTION_ICON[l.action]||'📌'}</span>
            <span style={{fontFamily:'monospace',fontSize:10,color:'#475569',minWidth:140,flexShrink:0}}>{new Date(l.ts).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span>
            <span style={{fontWeight:600,color:'#e2e8f0',minWidth:160,flexShrink:0}}>{l.action}</span>
            <span style={{color:'#94a3b8',flex:1}}>{l.detail}</span>
            {l.user && l.user!=='System' && <span style={{fontSize:10,color:'#475569',flexShrink:0}}>by {l.user}</span>}
          </div>
        ))}
      </Card>
    </div>
  );
}

// ════════════ WHISTLEBLOWER ════════════════════════════════════════════════════
export function Whistleblower() {
  const [done, setDone]     = useState(false);
  const [cat, setCat]       = useState('Money Laundering');
  const [content, setContent] = useState('');
  const [anon, setAnon]     = useState(true);
  const ref = React.useRef('WB-'+Math.random().toString(36).slice(2,10).toUpperCase());

  return (
    <div>
      <PHdr title="Whistleblower Portal" sub="Encrypted · Anonymous · On-chain · Protected under Dodd-Frank Act"/>
      <div style={{maxWidth:560}}>
        {!done ? (
          <Card>
            <div style={{background:'rgba(120,53,15,.3)',border:'1px solid rgba(146,64,14,.5)',borderRadius:10,padding:'0.85rem',fontSize:12,color:'#fcd34d',marginBottom:'1.2rem',display:'flex',gap:10,lineHeight:1.6}}>
              <span style={{fontSize:20,flexShrink:0}}>🔐</span>
              <span>Your identity is <strong>never stored</strong>. Submissions are AES-256 encrypted, anonymised, and hashed to the Ethereum blockchain. Legally protected under 18 U.S.C. § 1514A (Dodd-Frank).</span>
            </div>

            <div style={{marginBottom:'0.8rem'}}>
              <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>Category</div>
              <select value={cat} onChange={e=>setCat(e.target.value)}
                style={{width:'100%',background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'9px 13px',fontSize:13,outline:'none'}}>
                {['Money Laundering','Fraud / Embezzlement','Insider Trading','Regulatory Violation','Bribery / Corruption','Other'].map(o=><option key={o}>{o}</option>)}
              </select>
            </div>

            <div style={{marginBottom:'0.8rem'}}>
              <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>Describe the suspicious activity in detail</div>
              <textarea value={content} onChange={e=>setContent(e.target.value)} rows={5}
                placeholder="Include: dates, account numbers, amounts, individuals involved, departments, specific incidents..."
                style={{width:'100%',background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'9px 13px',fontSize:13,outline:'none',resize:'vertical',boxSizing:'border-box',fontFamily:"'DM Sans',sans-serif"}}/>
            </div>

            <label style={{display:'flex',alignItems:'center',gap:8,fontSize:12,color:'#94a3b8',marginBottom:'1.2rem',cursor:'pointer'}}>
              <input type="checkbox" checked={anon} onChange={e=>setAnon(e.target.checked)}/>
              Submit completely anonymously (recommended)
            </label>

            <button onClick={()=>content.trim()&&setDone(true)} disabled={!content.trim()}
              style={{width:'100%',background:'#4f6ef7',color:'#fff',border:'none',borderRadius:9,padding:12,fontSize:13,fontWeight:700,cursor:content.trim()?'pointer':'not-allowed',opacity:content.trim()?1:0.5}}>
              Submit Encrypted Report →
            </button>
          </Card>
        ) : (
          <Card style={{textAlign:'center',padding:'2.5rem 2rem'}}>
            <div style={{fontSize:48,marginBottom:12}}>✅</div>
            <h2 style={{fontFamily:"'Sora',sans-serif",color:'#fff',marginBottom:8}}>Report Submitted</h2>
            <p style={{fontSize:13,color:'#94a3b8',marginBottom:'1rem',lineHeight:1.6}}>
              Your report has been AES-256 encrypted, anonymized, and submitted to the compliance team. Your reference ID:
            </p>
            <div style={{fontFamily:'monospace',fontSize:16,color:'#818cf8',background:'#232635',padding:'10px 24px',borderRadius:10,display:'inline-block',border:'1px solid #3d4261'}}>
              {ref.current}
            </div>
            <p style={{fontSize:11,color:'#475569',marginTop:'1rem',lineHeight:1.5}}>
              This report will be hashed and recorded on Ethereum within ~30 seconds. You may use your reference ID to check status.
            </p>
            <div style={{marginTop:'1.2rem',padding:'0.7rem',background:'rgba(34,197,94,.08)',border:'1px solid rgba(34,197,94,.2)',borderRadius:9,fontSize:12,color:'#6ee7b7'}}>
              ⛓ Blockchain hash pending confirmation
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
