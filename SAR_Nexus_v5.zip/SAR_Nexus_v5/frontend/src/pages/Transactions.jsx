import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, ReferenceLine, RadarChart, Radar, PolarGrid, PolarAngleAxis, Cell } from 'recharts';
import { DB, ACCOUNTS, accountHistory, mlScore, subscribe } from '../data/store';
import { useAuth } from '../context/AuthContext';
import { Card, RiskBadge, SBadge, Btn, Modal, PHdr, Toast, TArea, TInput, SigBar, DataRow, riskColor, riskLabel } from '../components/UI';

const TT = { contentStyle:{background:'#1a1d27',border:'1px solid #3d4261',borderRadius:9,fontSize:11} };
const TX = { fill:'#475569',fontSize:11 };

// ═══════════ TRANSACTIONS LIST ═══════════════════════════════════════════════
export function Transactions() {
  const nav = useNavigate();
  const [, tick] = useState(0);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => subscribe(()=>tick(t=>t+1)), []);

  const txns = DB.transactions().filter(t => {
    if (filter !== 'all' && t.status !== filter) return false;
    const q = search.toLowerCase();
    return !q || t.id.toLowerCase().includes(q) || t.accountId.toLowerCase().includes(q) || t.type.toLowerCase().includes(q);
  });

  const filters = ['all','flagged','review','cleared'];

  return (
    <div>
      <PHdr title="Transactions" sub="All transactions with ML risk scoring — click Analyse to see full breakdown"/>
      <div style={{display:'flex',gap:'0.6rem',marginBottom:'1rem',flexWrap:'wrap'}}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by ID, account, type..."
          style={{background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,padding:'8px 13px',fontSize:12,outline:'none',flex:1,minWidth:200}}/>
        {filters.map(f=>(
          <button key={f} onClick={()=>setFilter(f)}
            style={{padding:'7px 16px',borderRadius:9,fontSize:12,fontWeight:600,cursor:'pointer',border:'none',
              background:filter===f?'#4f6ef7':'#1a1d27',color:filter===f?'#fff':'#64748b',border:`1px solid ${filter===f?'#4f6ef7':'#2d3147'}`}}>
            {f==='all'?'All':f[0].toUpperCase()+f.slice(1)} {f!=='all'&&`(${DB.transactions().filter(t=>t.status===f).length})`}
          </button>
        ))}
      </div>
      <Card style={{padding:0,overflow:'hidden'}}>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
          <thead>
            <tr style={{background:'#1e2535',borderBottom:'1px solid #2d3147'}}>
              {['Transaction ID','Account','Amount ($)','Type','Country','Risk Score','Status','Top Signal','Action'].map(h=>(
                <th key={h} style={{textAlign:'left',padding:'10px 12px',color:'#64748b',fontWeight:500,whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {txns.map(t=>{
              const top = Object.entries(t.signals||{}).sort((a,b)=>b[1]-a[1])[0];
              const acc = ACCOUNTS.find(a=>a.id===t.accountId);
              return (
                <tr key={t.id} style={{borderBottom:'1px solid #1a1d27',transition:'background .1s'}}
                  onMouseEnter={e=>e.currentTarget.style.background='#1e2535'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{padding:'10px 12px',color:'#818cf8',fontFamily:'monospace',whiteSpace:'nowrap'}}>{t.id}</td>
                  <td style={{padding:'10px 12px'}}>
                    <div style={{fontSize:12,color:'#e2e8f0',fontWeight:500}}>{acc?.name||t.accountId}</div>
                    <div style={{fontSize:10,color:'#475569'}}>{t.accountId}</div>
                  </td>
                  <td style={{padding:'10px 12px',color:'#fff',fontWeight:700}}>${t.amount.toLocaleString()}</td>
                  <td style={{padding:'10px 12px',color:'#64748b'}}>{t.type}</td>
                  <td style={{padding:'10px 12px',color:'#64748b'}}>{t.country}</td>
                  <td style={{padding:'10px 12px'}}><RiskBadge score={t.riskScore}/></td>
                  <td style={{padding:'10px 12px'}}><SBadge status={t.status}/></td>
                  <td style={{padding:'10px 12px',color:'#fbbf24',fontSize:11}}>
                    {top ? `⚠ ${top[0].slice(0,25)}` : <span style={{color:'#475569'}}>None</span>}
                  </td>
                  <td style={{padding:'10px 12px'}}>
                    <Btn sm onClick={()=>nav(`/transactions/${t.id}`)}>Analyse →</Btn>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {txns.length===0 && <div style={{textAlign:'center',padding:'3rem',color:'#475569',fontSize:13}}>No transactions match your filter</div>}
      </Card>
    </div>
  );
}

// ═══════════ TRANSACTION DETAIL — Full ML Analysis ════════════════════════════
export function TransactionDetail() {
  const { id } = useParams();
  const { user, can } = useAuth();
  const nav = useNavigate();
  const [, tick] = useState(0);
  const [toast, setToast] = useState(null);
  const [sarModal,  setSarModal]  = useState(false);
  const [warnModal, setWarnModal] = useState(false);
  const [emailModal,setEmailModal]= useState(false);
  const [warnMsg,   setWarnMsg]   = useState('');
  const [emailSub,  setEmailSub]  = useState('');
  const [emailBody, setEmailBody] = useState('');

  useEffect(() => subscribe(()=>tick(t=>t+1)), []);

  const txn = DB.transactions().find(t=>t.id===id);
  if (!txn) return <div style={{color:'#ef4444',padding:'2rem'}}>Transaction {id} not found</div>;

  const acc     = ACCOUNTS.find(a=>a.id===txn.accountId);
  const hist    = accountHistory(txn.accountId);
  const daily   = Math.round((acc?.avgMonthly||10000)/30);
  const ratio   = (txn.amount/Math.max(daily,1)).toFixed(1);
  const sigBars = Object.entries(txn.signals||{}).map(([k,v])=>({name:k,score:v})).sort((a,b)=>b.score-a.score);

  // Radar — 5 ML dimensions, unique per transaction
  const radar = [
    { s:'Amount',     A:Math.min(100,parseFloat(ratio)*14) },
    { s:'Velocity',   A:Math.min(100,(txn.velocity||0)*9) },
    { s:'Geo Risk',   A:['Cayman Islands','Panama','Belize','BVI','Vanuatu'].includes(txn.country)?90:12 },
    { s:'Structuring',A:txn.amount>9000&&txn.amount<10000?88:8 },
    { s:'Off-Hours',  A:txn.offHours?78:8 },
  ];

  const toast$ = (m,t='ok') => setToast({msg:m,type:t});

  const doCreateSAR = () => {
    const s = DB.createSAR(txn.id, user.name);
    toast$(`✅ SAR ${s.id} created — ready for review`);
    setSarModal(false); tick(t=>t+1);
  };
  const doWarn = () => {
    if (!warnMsg.trim()) return;
    DB.sendWarning(txn.accountId, warnMsg, user.name);
    toast$(`⚠ Warning issued to ${acc?.name}`, 'warn');
    setWarnModal(false); setWarnMsg('');
  };
  const doEmail = () => {
    if (!emailSub.trim()) return;
    DB.sendEmail(txn.accountId, emailSub, emailBody||'Please contact your relationship manager regarding this compliance matter.', user.name);
    toast$(`📧 Email sent to ${acc?.email}`);
    setEmailModal(false); setEmailSub(''); setEmailBody('');
  };

  // Check if SAR already exists
  const sarExists = DB.sars().some(s=>s.txnIds?.includes(txn.id));

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)}/>}

      {/* Breadcrumb + title */}
      <div>
        <button onClick={()=>nav('/transactions')} style={{fontSize:11,color:'#64748b',background:'none',border:'none',cursor:'pointer',marginBottom:6,padding:0}}>← Back to Transactions</button>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:'0.7rem'}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
              <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:18,fontWeight:600,color:'#fff',margin:0}}>{txn.id}</h1>
              <RiskBadge score={txn.riskScore} large/>
              <SBadge status={txn.status}/>
            </div>
            <p style={{fontSize:12,color:'#64748b',marginTop:5,marginBottom:0}}>
              {acc?.name} ({txn.accountId}) · {txn.type} · ${txn.amount.toLocaleString()} · {txn.country} · {txn.counterparty}
            </p>
          </div>
          {/* Action buttons — only shown when user has permission */}
          <div style={{display:'flex',gap:'0.5rem',flexWrap:'wrap'}}>
            {can('createSAR') && !sarExists && txn.riskScore>=55 && (
              <Btn onClick={()=>setSarModal(true)} color="#4f6ef7">📋 Create SAR</Btn>
            )}
            {sarExists && <span style={{fontSize:11,color:'#6ee7b7',padding:'8px 12px',background:'rgba(34,197,94,.1)',borderRadius:9,border:'1px solid rgba(34,197,94,.2)'}}>✅ SAR exists</span>}
            {can('sendWarning') && (
              <Btn onClick={()=>setWarnModal(true)} color="#f59e0b">⚠ Issue Warning</Btn>
            )}
            {can('sendWarning') && (
              <Btn onClick={()=>setEmailModal(true)} color="#8b5cf6">📧 Email Account</Btn>
            )}
          </div>
        </div>
      </div>

      {/* Row 1: Account history + Radar */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem'}}>
        <Card>
          <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:3}}>
            {acc?.name} — 12-Month Transaction History
          </div>
          <div style={{fontSize:11,color:'#64748b',marginBottom:10}}>
            Red dashed line = this transaction (${txn.amount.toLocaleString()}) · Daily avg = ${daily.toLocaleString()}
          </div>
          <ResponsiveContainer width="100%" height={195}>
            <BarChart data={hist}>
              <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
              <YAxis tick={TX} axisLine={false} tickLine={false} tickFormatter={v=>'$'+Math.round(v/1000)+'k'}/>
              <Tooltip {...TT} formatter={v=>'$'+v.toLocaleString()}/>
              <ReferenceLine y={txn.amount} stroke="#ef4444" strokeDasharray="5 5" strokeWidth={2}
                label={{value:`This txn $${Math.round(txn.amount/1000)}k`,fill:'#ef4444',fontSize:9,position:'insideTopRight'}}/>
              <Bar dataKey="amount" name="Monthly Total" radius={[3,3,0,0]}>
                {hist.map((entry,i)=>(
                  <Cell key={i} fill={entry.amount>=txn.amount?'#ef4444':'#4f6ef7'}/>
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div style={{fontSize:11,color:'#64748b',marginTop:6}}>
            🔴 Red bars = months where spending exceeded this transaction · 🔵 Blue = normal months
          </div>
        </Card>

        <Card>
          <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:3}}>ML Risk Signal Radar</div>
          <div style={{fontSize:11,color:'#64748b',marginBottom:6}}>5 fraud dimensions analysed — larger = higher risk</div>
          <ResponsiveContainer width="100%" height={195}>
            <RadarChart data={radar}>
              <PolarGrid stroke="#2d3147"/>
              <PolarAngleAxis dataKey="s" tick={{fill:'#64748b',fontSize:10}}/>
              <Radar name="Risk" dataKey="A" stroke={riskColor(txn.riskScore)} fill={riskColor(txn.riskScore)} fillOpacity={0.25}/>
              <Tooltip {...TT}/>
            </RadarChart>
          </ResponsiveContainer>
          <div style={{textAlign:'center',marginTop:4}}>
            <span style={{fontSize:11,color:riskColor(txn.riskScore),fontWeight:700}}>{riskLabel(txn.riskScore)}</span>
            <span style={{fontSize:11,color:'#475569',marginLeft:8}}>· Confidence: {(txn.riskScore/100+0.05).toFixed(2)}</span>
          </div>
        </Card>
      </div>

      {/* Row 2: SHAP bars + Transaction facts */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem'}}>
        <Card>
          <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:12}}>🔍 Explainable AI — Why Flagged</div>
          {sigBars.length===0
            ? <div style={{color:'#6ee7b7',fontSize:12,textAlign:'center',padding:'1.5rem'}}>✅ No suspicious signals — transaction appears normal</div>
            : sigBars.map(s=><SigBar key={s.name} label={s.name} score={s.score}/>)
          }
          <div style={{borderTop:'1px solid #2d3147',marginTop:12,paddingTop:12,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <span style={{fontSize:12,color:'#64748b'}}>Total ML risk score</span>
            <div style={{display:'flex',alignItems:'center',gap:8}}>
              <RiskBadge score={txn.riskScore} large/>
              <span style={{fontSize:11,color:riskColor(txn.riskScore),fontWeight:700}}>{riskLabel(txn.riskScore)}</span>
            </div>
          </div>
          <div style={{marginTop:8,fontSize:11,color:'#475569',fontStyle:'italic'}}>{txn.notes}</div>
        </Card>

        <Card>
          <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:12}}>📋 Transaction Facts</div>
          <DataRow label="Transaction ID"   value={txn.id}                     mono/>
          <DataRow label="Account"          value={`${txn.accountId} — ${acc?.name||'Unknown'}`}/>
          <DataRow label="Amount"           value={`$${txn.amount.toLocaleString()}`}/>
          <DataRow label="Account Avg/Day"  value={`$${daily.toLocaleString()}`}/>
          <DataRow label="Amount Ratio"     value={`${ratio}× daily average`}/>
          <DataRow label="Transaction Type" value={txn.type}/>
          <DataRow label="Country"          value={txn.country}/>
          <DataRow label="Counterparty"     value={txn.counterparty}/>
          <DataRow label="Velocity (24h)"   value={`${txn.velocity} transactions`}/>
          <DataRow label="Off-Hours"        value={txn.offHours?'⚠ Yes (2am–6am)':'✅ Normal hours'}/>
          <DataRow label="Time"             value={new Date(txn.time).toLocaleString()}/>
        </Card>
      </div>

      {/* Modals */}
      <Modal open={sarModal} onClose={()=>setSarModal(false)} title="📋 Create SAR Report">
        <div style={{background:'#1e2535',borderRadius:10,padding:'0.9rem',marginBottom:'1rem',fontSize:12}}>
          <div style={{color:'#94a3b8',marginBottom:6}}>This will auto-generate a SAR using ML signals from <strong style={{color:'#fff'}}>{txn.id}</strong>. Status will be <strong style={{color:'#fcd34d'}}>Pending Review</strong> until an officer approves it.</div>
          <DataRow label="Account"     value={`${txn.accountId} — ${acc?.name}`}/>
          <DataRow label="Amount"      value={`$${txn.amount.toLocaleString()}`}/>
          <DataRow label="Risk Score"  value={<RiskBadge score={txn.riskScore}/>}/>
          <DataRow label="Key Signal"  value={sigBars[0]?.name||'None'}/>
        </div>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setSarModal(false)}>Cancel</Btn>
          <Btn onClick={doCreateSAR}>✅ Create SAR Draft</Btn>
        </div>
      </Modal>

      <Modal open={warnModal} onClose={()=>setWarnModal(false)} title="⚠ Issue Warning to Account Holder">
        <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.8rem'}}>Warning will be logged in the Audit Log against account <strong style={{color:'#fff'}}>{txn.accountId} ({acc?.name})</strong>.</div>
        <TArea label="Warning message" value={warnMsg} onChange={e=>setWarnMsg(e.target.value)}
          placeholder="e.g. Your account has been flagged for suspicious activity under FinCEN compliance guidelines. Further transactions may be subject to additional scrutiny..."/>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setWarnModal(false)}>Cancel</Btn>
          <Btn color="#f59e0b" onClick={doWarn}>⚠ Issue Warning</Btn>
        </div>
      </Modal>

      <Modal open={emailModal} onClose={()=>setEmailModal(false)} title="📧 Send Email Notice">
        <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.8rem'}}>Sending to: <strong style={{color:'#fff'}}>{acc?.email}</strong></div>
        <TInput label="Subject" value={emailSub} onChange={e=>setEmailSub(e.target.value)}
          placeholder="e.g. Compliance Notice — Account Review Required"/>
        <TArea label="Message body (optional)" value={emailBody} onChange={e=>setEmailBody(e.target.value)}
          placeholder="e.g. Dear account holder, your account has been flagged for a mandatory compliance review..."/>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setEmailModal(false)}>Cancel</Btn>
          <Btn color="#8b5cf6" onClick={doEmail}>📧 Send Email</Btn>
        </div>
      </Modal>
    </div>
  );
}
