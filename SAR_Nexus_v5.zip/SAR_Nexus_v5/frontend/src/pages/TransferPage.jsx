import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { DB, subscribe } from '../data/store';

const fmtC = n => '$' + Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});

const TRANSFER_TYPES = ['ACH Transfer','Wire Transfer','Instant Transfer','SWIFT Transfer','Zelle'];
const BANKS = ['Chase Bank','Bank of America','Wells Fargo','Citibank','US Bank','TD Bank','PNC Bank','Capital One','Ally Bank','SoFi'];

function Step({ n, label, active, done }) {
  return (
    <div style={{display:'flex',alignItems:'center',gap:8}}>
      <div style={{width:28,height:28,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,transition:'all .3s',
        background: done?'#22c55e':active?'#4f6ef7':'#1e2435',
        color: done||active?'#fff':'#475569',
        boxShadow: active?'0 0 16px rgba(79,110,247,0.5)':done?'0 0 12px rgba(34,197,94,0.4)':'none'}}>
        {done?'✓':n}
      </div>
      <span style={{fontSize:12,fontWeight:600,color:active?'#e2e8f0':done?'#22c55e':'#475569'}}>{label}</span>
    </div>
  );
}

function Input({ label, value, onChange, type='text', placeholder, mono }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{marginBottom:'1rem'}}>
      <label style={{fontSize:10,color:'#64748b',fontWeight:700,letterSpacing:0.5,display:'block',marginBottom:5}}>{label}</label>
      <input value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder}
        style={{width:'100%',background:'#080b12',border:`1px solid ${focused?'#4f6ef7':'#1e2435'}`,color:'#e2e8f0',borderRadius:9,padding:'11px 14px',fontSize:13,boxSizing:'border-box',outline:'none',fontFamily:mono?'monospace':"'DM Sans',sans-serif",transition:'border .15s'}}
        onFocus={()=>setFocused(true)}
        onBlur={()=>setFocused(false)}
      />
    </div>
  );
}

export default function TransferPage() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [bal,  setBal]  = useState(10000);
  const [txns, setTxns] = useState([]);

  useEffect(()=>{
    const r=()=>{ setBal(DB.getBalance(user?.accountId)); setTxns(DB.userTransactions(user?.accountId)); };
    r(); return subscribe(r);
  },[user]);

  const [step,    setStep]   = useState(1);
  const [method,  setMethod] = useState('account');
  const [toName,  setToName] = useState('');
  const [toAcct,  setToAcct] = useState('');
  const [bank,    setBank]   = useState('Chase Bank');
  const [routing, setRouting]= useState('');
  const [amount,  setAmount] = useState('');
  const [txType,  setTxType] = useState('ACH Transfer');
  const [note,    setNote]   = useState('');
  const [pin,     setPin]    = useState('');
  const [err,     setErr]    = useState('');
  const [busy,    setBusy]   = useState(false);
  const [done,    setDone]   = useState(false);
  const [lastTxn, setLastTxn]= useState(null);

  const amt = parseFloat(amount) || 0;
  const fee = txType === 'Wire Transfer' ? 15 : txType === 'SWIFT Transfer' ? 25 : 0;

  const validate1 = ()=>{
    if (!toName.trim())                         { setErr('Enter recipient name'); return false; }
    if (method==='account' && !toAcct.trim())   { setErr('Enter account number'); return false; }
    if (method==='bank'    && !routing.trim())  { setErr('Enter routing number'); return false; }
    if (method==='contact' && !toAcct.trim())   { setErr('Enter phone or email'); return false; }
    setErr(''); return true;
  };
  const validate2 = ()=>{
    if (!amt || amt<=0)    { setErr('Enter a valid amount'); return false; }
    if (amt+fee > bal)     { setErr(`Insufficient balance. Available: ${fmtC(bal)}`); return false; }
    if (amt > 50000)       { setErr('Limit per transfer: $50,000'); return false; }
    setErr(''); return true;
  };
  const validate3 = ()=>{
    if (pin !== '1234')    { setErr('Incorrect PIN  (Demo PIN: 1234)'); return false; }
    setErr(''); return true;
  };

  const submit = async () => {
    if (!validate3()) return;
    setBusy(true);
    await new Promise(r=>setTimeout(r,1400));
    try {
      const txn = DB.transferMoney({
        fromAccountId: user.accountId,
        toName,
        toAccount: toAcct || routing,
        amount: amt,
        type: txType,
        note,
        userName: user.name,
      });
      setLastTxn(txn);
      setDone(true);
    } catch(e) { setErr(e.message); }
    setBusy(false);
  };

  const reset = ()=>{ setDone(false); setStep(1); setToName(''); setToAcct(''); setRouting(''); setAmount(''); setNote(''); setPin(''); setErr(''); };

  if (done && lastTxn) return (
    <div style={{minHeight:'100vh',background:'#080b12',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'DM Sans',sans-serif",padding:'1.5rem'}}>
      <div style={{maxWidth:460,width:'100%',textAlign:'center'}}>
        <div style={{width:80,height:80,borderRadius:'50%',background:'rgba(34,197,94,0.15)',border:'2px solid #22c55e',display:'flex',alignItems:'center',justifyContent:'center',fontSize:36,margin:'0 auto 1.5rem',boxShadow:'0 0 40px rgba(34,197,94,0.3)',animation:'pop .5s ease'}}>✓</div>
        <style>{`@keyframes pop{from{transform:scale(0);opacity:0}to{transform:scale(1);opacity:1}}`}</style>
        <h2 style={{fontFamily:"'Sora',sans-serif",fontSize:22,fontWeight:700,color:'#fff',margin:'0 0 .5rem'}}>Transfer Submitted!</h2>
        <p style={{color:'#475569',fontSize:13,margin:'0 0 1.5rem'}}>Your transfer is pending admin review. You'll see it update in your dashboard.</p>
        <div style={{background:'#0d1018',border:'1px solid rgba(245,158,11,0.25)',borderRadius:14,padding:'1.25rem',textAlign:'left',marginBottom:'1.5rem'}}>
          <div style={{fontSize:10,color:'#f59e0b',fontWeight:700,marginBottom:'0.75rem'}}>⏳ PENDING REVIEW</div>
          {[
            ['Recipient', toName],
            ['Amount',    fmtC(amt)],
            ['Fee',       fee?fmtC(fee):'Free'],
            ['Type',      txType],
            ['Ref',       lastTxn.id],
            ['Status',    'Pending Admin Review'],
          ].map(([k,v])=>(
            <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'7px 0',borderBottom:'1px solid #1a1f2e'}}>
              <span style={{fontSize:12,color:'#475569'}}>{k}</span>
              <span style={{fontSize:12,fontWeight:700,color: k==='Status'?'#f59e0b':k==='Amount'?'#e2e8f0':'#e2e8f0'}}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{display:'flex',gap:'0.75rem'}}>
          <button onClick={reset} style={{flex:1,background:'rgba(79,110,247,0.12)',border:'1px solid rgba(79,110,247,0.25)',color:'#818cf8',borderRadius:10,padding:12,cursor:'pointer',fontSize:13,fontWeight:700}}>New Transfer</button>
          <button onClick={()=>nav('/user-dashboard')} style={{flex:1,background:'linear-gradient(135deg,#22c55e,#16a34a)',border:'none',color:'#fff',borderRadius:10,padding:12,cursor:'pointer',fontSize:13,fontWeight:700}}>Go to Dashboard →</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{minHeight:'100vh',background:'#080b12',fontFamily:"'DM Sans',sans-serif",color:'#fff'}}>
      <header style={{background:'#0a0d14',borderBottom:'1px solid #1a1f2e',padding:'0 1.5rem',display:'flex',alignItems:'center',justifyContent:'space-between',height:54}}>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <button onClick={()=>nav('/user-dashboard')} style={{background:'transparent',border:'1px solid #1e2435',borderRadius:8,color:'#64748b',padding:'5px 12px',cursor:'pointer',fontSize:11}}>← Back</button>
          <span style={{fontSize:14,fontWeight:700,color:'#e2e8f0'}}>💸 Send Money</span>
        </div>
        <span style={{fontSize:12,color:'#475569'}}>Balance: <span style={{color:'#22c55e',fontWeight:700}}>{fmtC(bal)}</span></span>
      </header>

      <div style={{maxWidth:760,margin:'0 auto',padding:'1.5rem'}}>

        {/* Step indicators */}
        <div style={{display:'flex',alignItems:'center',gap:0,marginBottom:'1.75rem',background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:14,padding:'1rem 1.5rem'}}>
          <Step n={1} label="Recipient" active={step===1} done={step>1}/>
          <div style={{flex:1,height:1,background:step>1?'rgba(34,197,94,0.3)':'#1e2435',margin:'0 14px',transition:'background .3s'}}/>
          <Step n={2} label="Amount"    active={step===2} done={step>2}/>
          <div style={{flex:1,height:1,background:step>2?'rgba(34,197,94,0.3)':'#1e2435',margin:'0 14px',transition:'background .3s'}}/>
          <Step n={3} label="Confirm"   active={step===3} done={false}/>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:'1.25rem',alignItems:'start'}}>

          {/* Form */}
          <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.5rem'}}>

            {/* Step 1 */}
            {step===1 && (
              <>
                <h3 style={{fontSize:15,fontWeight:700,color:'#e2e8f0',margin:'0 0 1.25rem'}}>Who are you sending to?</h3>
                <div style={{display:'flex',gap:6,marginBottom:'1.25rem'}}>
                  {[['account','🏦 Account'],['bank','🔢 Bank'],['contact','📱 Phone/Email']].map(([v,l])=>(
                    <button key={v} onClick={()=>{setMethod(v);setErr('');}}
                      style={{flex:1,padding:'8px 6px',borderRadius:8,border:`1px solid ${method===v?'#4f6ef7':'#1e2435'}`,background:method===v?'rgba(79,110,247,0.12)':'transparent',color:method===v?'#818cf8':'#475569',cursor:'pointer',fontSize:11,fontWeight:700,transition:'all .15s'}}>
                      {l}
                    </button>
                  ))}
                </div>
                <Input label="RECIPIENT NAME *" value={toName} onChange={setToName} placeholder="Full name or company"/>
                {method==='account' && <Input label="ACCOUNT NUMBER *" value={toAcct} onChange={setToAcct} placeholder="e.g. ACC-1234" mono/>}
                {method==='bank' && (
                  <>
                    <div style={{marginBottom:'1rem'}}>
                      <label style={{fontSize:10,color:'#64748b',fontWeight:700,letterSpacing:0.5,display:'block',marginBottom:5}}>BANK</label>
                      <select value={bank} onChange={e=>setBank(e.target.value)}
                        style={{width:'100%',background:'#080b12',border:'1px solid #1e2435',color:'#e2e8f0',borderRadius:9,padding:'11px 14px',fontSize:13,boxSizing:'border-box',outline:'none'}}>
                        {BANKS.map(b=><option key={b}>{b}</option>)}
                      </select>
                    </div>
                    <Input label="ROUTING NUMBER *" value={routing} onChange={setRouting} placeholder="9-digit routing number" mono/>
                  </>
                )}
                {method==='contact' && <Input label="PHONE / EMAIL *" value={toAcct} onChange={setToAcct} placeholder="e.g. +1-555-000-0000 or name@email.com"/>}
                {err && <div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.25)',borderRadius:8,padding:'10px 14px',color:'#fca5a5',fontSize:12,marginBottom:'1rem'}}>⚠ {err}</div>}
                <button onClick={()=>{ if(validate1()) setStep(2); }} style={{width:'100%',background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:10,padding:13,fontSize:13,fontWeight:700,cursor:'pointer',boxShadow:'0 4px 18px rgba(79,110,247,0.35)'}}>Continue →</button>
              </>
            )}

            {/* Step 2 */}
            {step===2 && (
              <>
                <h3 style={{fontSize:15,fontWeight:700,color:'#e2e8f0',margin:'0 0 .5rem'}}>How much to send?</h3>
                <div style={{fontSize:12,color:'#475569',marginBottom:'1.5rem'}}>To: <span style={{color:'#e2e8f0',fontWeight:600}}>{toName}</span></div>

                <div style={{textAlign:'center',marginBottom:'1.5rem'}}>
                  <div style={{fontSize:11,color:'#64748b',marginBottom:8}}>AMOUNT (USD)</div>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:4}}>
                    <span style={{fontSize:32,fontWeight:700,color:'#475569'}}>$</span>
                    <input value={amount} onChange={e=>setAmount(e.target.value.replace(/[^0-9.]/g,''))} type="number" min="0" placeholder="0.00"
                      style={{background:'transparent',border:'none',outline:'none',fontSize:48,fontWeight:700,color:'#fff',fontFamily:"'Sora',sans-serif",width:210,textAlign:'center'}}/>
                  </div>
                  <div style={{fontSize:12,color:'#475569',marginTop:4}}>Available: <span style={{color:'#22c55e',fontWeight:700}}>{fmtC(bal)}</span></div>
                </div>

                <div style={{display:'flex',gap:8,justifyContent:'center',marginBottom:'1.25rem',flexWrap:'wrap'}}>
                  {[100,250,500,1000,2500].map(q=>(
                    <button key={q} onClick={()=>setAmount(String(q))}
                      style={{background: amt===q?'rgba(79,110,247,0.2)':'rgba(255,255,255,0.04)',border:`1px solid ${amt===q?'#4f6ef7':'rgba(255,255,255,0.08)'}`,color:amt===q?'#818cf8':'#64748b',borderRadius:8,padding:'6px 14px',cursor:'pointer',fontSize:11,fontWeight:700,transition:'all .15s'}}>
                      ${q.toLocaleString()}
                    </button>
                  ))}
                </div>

                <div style={{marginBottom:'1rem'}}>
                  <label style={{fontSize:10,color:'#64748b',fontWeight:700,letterSpacing:0.5,display:'block',marginBottom:5}}>TRANSFER TYPE</label>
                  <select value={txType} onChange={e=>setTxType(e.target.value)}
                    style={{width:'100%',background:'#080b12',border:'1px solid #1e2435',color:'#e2e8f0',borderRadius:9,padding:'11px 14px',fontSize:13,boxSizing:'border-box',outline:'none'}}>
                    {TRANSFER_TYPES.map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>

                <Input label="NOTE (OPTIONAL)" value={note} onChange={setNote} placeholder="What's this for? e.g. Rent payment"/>

                {fee>0 && (
                  <div style={{background:'rgba(245,158,11,0.08)',border:'1px solid rgba(245,158,11,0.2)',borderRadius:9,padding:'10px 14px',fontSize:12,color:'#f59e0b',marginBottom:'1rem',display:'flex',alignItems:'center',gap:8}}>
                    ⚠ {txType} includes a {fmtC(fee)} fee
                  </div>
                )}

                {err && <div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.25)',borderRadius:8,padding:'10px 14px',color:'#fca5a5',fontSize:12,marginBottom:'1rem'}}>⚠ {err}</div>}
                <div style={{display:'flex',gap:'0.75rem'}}>
                  <button onClick={()=>setStep(1)} style={{flex:'0 0 auto',background:'transparent',border:'1px solid #1e2435',color:'#64748b',borderRadius:10,padding:'12px 18px',cursor:'pointer',fontSize:13,fontWeight:700}}>← Back</button>
                  <button onClick={()=>{ if(validate2()) setStep(3); }} style={{flex:1,background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:10,padding:12,cursor:'pointer',fontSize:13,fontWeight:700,boxShadow:'0 4px 18px rgba(79,110,247,0.35)'}}>Review →</button>
                </div>
              </>
            )}

            {/* Step 3 */}
            {step===3 && (
              <>
                <h3 style={{fontSize:15,fontWeight:700,color:'#e2e8f0',margin:'0 0 1.25rem'}}>Review & Confirm</h3>
                <div style={{background:'#080b12',border:'1px solid #1e2435',borderRadius:12,padding:'1.25rem',marginBottom:'1.25rem'}}>
                  {[
                    ['From',     user?.name],
                    ['To',       toName],
                    ['Ref',      toAcct||routing||'—'],
                    ['Amount',   fmtC(amt)],
                    ['Fee',      fee?fmtC(fee):'Free'],
                    ['Total',    fmtC(amt+fee)],
                    ['Type',     txType],
                    ['Note',     note||'—'],
                    ['Arrives',  txType==='Instant Transfer'?'Instantly (after approval)':'1–3 days (after approval)'],
                  ].map(([k,v])=>(
                    <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'1px solid #1a1f2e'}}>
                      <span style={{fontSize:12,color:'#64748b'}}>{k}</span>
                      <span style={{fontSize:12,fontWeight:700,color: k==='Total'?'#ef4444':k==='Fee'?'#f59e0b':'#e2e8f0'}}>{v}</span>
                    </div>
                  ))}
                </div>

                <div style={{background:'rgba(245,158,11,0.06)',border:'1px solid rgba(245,158,11,0.2)',borderRadius:10,padding:'10px 14px',fontSize:11,color:'#64748b',marginBottom:'1.25rem',lineHeight:1.6}}>
                  ⏳ This transfer will be submitted for admin review. Your balance will be reserved until approved or rejected.
                </div>

                <div style={{marginBottom:'1.25rem'}}>
                  <label style={{fontSize:10,color:'#64748b',fontWeight:700,letterSpacing:0.5,display:'block',marginBottom:5}}>ENTER 4-DIGIT PIN <span style={{color:'#334155',fontWeight:400}}>(Demo: 1234)</span></label>
                  <input value={pin} onChange={e=>setPin(e.target.value.slice(0,4))} type="password" maxLength={4} placeholder="••••"
                    style={{width:'100%',background:'#080b12',border:`1px solid ${pin.length===4?'#4f6ef7':'#1e2435'}`,color:'#e2e8f0',borderRadius:9,padding:'13px',fontSize:22,boxSizing:'border-box',outline:'none',textAlign:'center',letterSpacing:10,fontFamily:'monospace',transition:'border .2s'}}
                  />
                </div>

                {err && <div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.25)',borderRadius:8,padding:'10px 14px',color:'#fca5a5',fontSize:12,marginBottom:'1rem'}}>⚠ {err}</div>}
                <div style={{display:'flex',gap:'0.75rem'}}>
                  <button onClick={()=>setStep(2)} style={{flex:'0 0 auto',background:'transparent',border:'1px solid #1e2435',color:'#64748b',borderRadius:10,padding:'12px 18px',cursor:'pointer',fontSize:13,fontWeight:700}}>← Back</button>
                  <button onClick={submit} disabled={busy||pin.length<4}
                    style={{flex:1,background: busy||pin.length<4?'#1e2435':'linear-gradient(135deg,#22c55e,#16a34a)',color: busy||pin.length<4?'#475569':'#fff',border:'none',borderRadius:10,padding:12,cursor:busy||pin.length<4?'not-allowed':'pointer',fontSize:13,fontWeight:700,transition:'all .2s',boxShadow: busy||pin.length<4?'none':'0 4px 18px rgba(34,197,94,0.35)'}}>
                    {busy?(
                      <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                        <span style={{width:13,height:13,border:'2px solid rgba(255,255,255,0.3)',borderTop:'2px solid #fff',borderRadius:'50%',display:'inline-block',animation:'spin .8s linear infinite'}}/>
                        Submitting…
                      </span>
                    ):'Confirm & Submit ✓'}
                    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Sidebar */}
          <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
            <div style={{background:'linear-gradient(135deg,#0a1a10,#0d1a14)',border:'1px solid rgba(34,197,94,0.2)',borderRadius:14,padding:'1.25rem'}}>
              <div style={{fontSize:10,color:'#22c55e',fontWeight:700,letterSpacing:0.5,marginBottom:6}}>YOUR BALANCE</div>
              <div style={{fontFamily:"'Sora',sans-serif",fontSize:28,fontWeight:700,color:'#fff',marginBottom:4}}>{fmtC(bal)}</div>
              <div style={{fontSize:11,color:'#475569'}}>{user?.accountId}</div>
            </div>

            <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:14,padding:'1.25rem'}}>
              <div style={{fontSize:12,fontWeight:700,color:'#e2e8f0',marginBottom:'0.75rem'}}>🕐 Recent Transfers</div>
              {txns.length===0
                ? <div style={{fontSize:11,color:'#334155',textAlign:'center',padding:'1rem 0'}}>No transfers yet</div>
                : txns.slice(0,4).map(t=>(
                    <div key={t.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 0',borderBottom:'1px solid #1a1f2e'}}>
                      <div style={{minWidth:0}}>
                        <div style={{fontSize:11,color:'#e2e8f0',fontWeight:600,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.counterparty}</div>
                        <div style={{fontSize:9,color:'#475569'}}>{new Date(t.time).toLocaleDateString('en-US',{month:'short',day:'numeric'})}</div>
                      </div>
                      <div style={{textAlign:'right',flexShrink:0,paddingLeft:8}}>
                        <div style={{fontSize:11,fontWeight:700,color:'#ef4444'}}>-{fmtC(t.amount)}</div>
                        <div style={{fontSize:9,color: t.status==='pending_review'?'#f59e0b':t.status==='cleared'?'#22c55e':'#ef4444',fontWeight:700}}>{t.status==='pending_review'?'Pending':t.status==='cleared'?'Done':'Rejected'}</div>
                      </div>
                    </div>
                  ))
              }
            </div>

            <div style={{background:'rgba(79,110,247,0.06)',border:'1px solid rgba(79,110,247,0.15)',borderRadius:12,padding:'1rem'}}>
              <div style={{fontSize:11,fontWeight:700,color:'#4f6ef7',marginBottom:6}}>🔒 How it works</div>
              <div style={{fontSize:10,color:'#475569',lineHeight:1.7}}>
                1. Submit your transfer<br/>
                2. Admin reviews it<br/>
                3. Get approved or rejected<br/>
                4. Refunded if rejected
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
