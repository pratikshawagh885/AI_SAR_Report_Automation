import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { DB, subscribe } from '../data/store';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

const fmtC = n => '$' + Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

const STATUS_CFG = {
  pending_review: { color:'#f59e0b', bg:'rgba(245,158,11,0.12)', label:'Pending Review' },
  cleared:        { color:'#22c55e', bg:'rgba(34,197,94,0.12)',  label:'Approved'       },
  rejected:       { color:'#ef4444', bg:'rgba(239,68,68,0.12)', label:'Rejected'       },
  flagged:        { color:'#a78bfa', bg:'rgba(167,139,250,0.12)',label:'SAR Flagged'    },
};

function StatCard({ icon, label, value, color, sub }) {
  return (
    <div style={{background:'#0d1018',border:`1px solid ${color}22`,borderRadius:14,padding:'1.1rem',position:'relative',overflow:'hidden'}}>
      <div style={{position:'absolute',top:0,right:0,width:60,height:60,background:`radial-gradient(circle at top right,${color}18,transparent 70%)`}}/>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
        <span style={{fontSize:10,color:'#475569',fontWeight:600,letterSpacing:0.5,textTransform:'uppercase'}}>{label}</span>
        <span style={{fontSize:20}}>{icon}</span>
      </div>
      <div style={{fontSize:24,fontWeight:700,color:'#fff',fontFamily:"'Sora',sans-serif"}}>{value}</div>
      {sub && <div style={{fontSize:10,color:'#475569',marginTop:3}}>{sub}</div>}
    </div>
  );
}

function TRow({ t }) {
  const sc = STATUS_CFG[t.status] || STATUS_CFG.pending_review;
  const isIn = t.direction === 'in';
  return (
    <div style={{display:'flex',alignItems:'center',gap:14,padding:'12px 0',borderBottom:'1px solid #1a1f2e'}}>
      <div style={{width:38,height:38,borderRadius:11,background: isIn?'rgba(34,197,94,0.12)':'rgba(79,110,247,0.12)',border:`1px solid ${isIn?'rgba(34,197,94,0.2)':'rgba(79,110,247,0.2)'}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0}}>
        {isIn ? '💰' : '💸'}
      </div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontSize:13,fontWeight:600,color:'#e2e8f0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.counterparty}</div>
        <div style={{fontSize:11,color:'#475569'}}>{t.type} · {new Date(t.time).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</div>
        {t.notes && <div style={{fontSize:10,color:'#334155',marginTop:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>📝 {t.notes}</div>}
      </div>
      <div style={{textAlign:'right',flexShrink:0}}>
        <div style={{fontSize:14,fontWeight:700,color: isIn?'#22c55e':'#e2e8f0'}}>{isIn?'+':'-'}{fmtC(t.amount)}</div>
        <div style={{marginTop:3}}>
          <span style={{fontSize:9,fontWeight:700,color:sc.color,background:sc.bg,border:`1px solid ${sc.color}35`,padding:'1px 8px',borderRadius:20}}>{sc.label}</span>
        </div>
      </div>
    </div>
  );
}

function CTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:10,padding:'10px 14px'}}>
      <div style={{fontSize:10,color:'#64748b',marginBottom:4}}>{label}</div>
      {payload.map((p,i)=>(
        <div key={i} style={{fontSize:12,fontWeight:700,color:p.color||'#fff'}}>{p.name}: {typeof p.value==='number'?'$'+p.value.toLocaleString():p.value}</div>
      ))}
    </div>
  );
}

const TABS = [
  { id:'overview',      label:'Overview',      icon:'🏠' },
  { id:'transactions',  label:'Transactions',  icon:'💳' },
  { id:'analytics',     label:'Analytics',     icon:'📊' },
];

export default function UserDashboard() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [txns, setTxns]   = useState([]);
  const [bal,  setBal]    = useState(10000);
  const [tab,  setTab]    = useState('overview');

  useEffect(() => {
    DB.seedUserTransactions(user?.accountId, user?.name);
    const refresh = () => {
      const accountId = user?.accountId;
      if (!accountId) return;
      setTxns(DB.userTransactions(accountId));
      setBal(DB.getBalance(accountId));
    };
    refresh();
    return subscribe(refresh);
  }, [user]);

  const sent     = txns.filter(t => t.direction === 'out').reduce((s,t) => s+t.amount, 0);
  const received = txns.filter(t => t.direction === 'in').reduce((s,t) => s+t.amount, 0);
  const pending  = txns.filter(t => t.status === 'pending_review');
  const approved = txns.filter(t => t.status === 'cleared');
  const rejected = txns.filter(t => t.status === 'rejected');

  // Monthly data
  const monthlyData = MONTHS.map((m, i) => {
    const mt = txns.filter(t => new Date(t.time).getMonth() === i);
    return {
      month: m,
      Sent:     mt.filter(t=>t.direction==='out').reduce((s,t)=>s+t.amount,0),
      Received: mt.filter(t=>t.direction==='in').reduce((s,t)=>s+t.amount,0),
      Count:    mt.length,
    };
  });

  // Per-status breakdown for pie
  const pieData = [
    { name:'Approved', value: approved.length, color:'#22c55e' },
    { name:'Pending',  value: pending.length,  color:'#f59e0b' },
    { name:'Rejected', value: rejected.length, color:'#ef4444' },
  ].filter(d => d.value > 0);

  const TX = { fill:'#475569', fontSize:10 };

  return (
    <div style={{minHeight:'100vh', background:'#080b12', fontFamily:"'DM Sans',sans-serif", color:'#fff'}}>

      {/* Navbar */}
      <header style={{background:'#0a0d14',borderBottom:'1px solid #1a1f2e',padding:'0 1.5rem',display:'flex',alignItems:'center',justifyContent:'space-between',height:56,position:'sticky',top:0,zIndex:100}}>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div style={{width:34,height:34,background:'linear-gradient(135deg,#22c55e,#16a34a)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,boxShadow:'0 0 18px rgba(34,197,94,0.35)'}}>⚡</div>
          <div>
            <div style={{fontFamily:"'Sora',sans-serif",fontSize:14,fontWeight:700,color:'#fff'}}>SAR Nexus</div>
            <div style={{fontSize:9,color:'#22c55e',fontWeight:700,letterSpacing:0.8}}>MY BANKING</div>
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div style={{width:30,height:30,borderRadius:9,background:'rgba(34,197,94,0.15)',border:'1px solid rgba(34,197,94,0.3)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#22c55e'}}>{user?.avatar}</div>
          <span style={{fontSize:12,color:'#64748b'}}>{user?.name}</span>
          <button onClick={()=>{logout();nav('/login');}} style={{background:'transparent',border:'1px solid #1e2435',borderRadius:8,color:'#64748b',padding:'5px 12px',cursor:'pointer',fontSize:11}}>
            🚪 Sign out
          </button>
        </div>
      </header>

      <div style={{maxWidth:1060,margin:'0 auto',padding:'1.5rem'}}>

        {/* Balance hero */}
        <div style={{background:'linear-gradient(135deg,#0a1a10 0%,#0d1a14 50%,#0a1018 100%)',border:'1px solid rgba(34,197,94,0.2)',borderRadius:20,padding:'1.75rem',marginBottom:'1.5rem',position:'relative',overflow:'hidden'}}>
          <div style={{position:'absolute',top:0,right:0,width:280,height:280,background:'radial-gradient(circle at top right,rgba(34,197,94,0.12),transparent 70%)'}}/>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:'1rem'}}>
            <div>
              <div style={{fontSize:10,color:'#22c55e',fontWeight:700,letterSpacing:1,marginBottom:6}}>ACCOUNT BALANCE</div>
              <div style={{fontFamily:"'Sora',sans-serif",fontSize:42,fontWeight:700,color:'#fff',lineHeight:1,marginBottom:6}}>{fmtC(bal)}</div>
              <div style={{fontSize:11,color:'#475569'}}>{user?.accountId} · Personal Account</div>
              <div style={{display:'flex',alignItems:'center',gap:6,marginTop:8}}>
                <span style={{width:6,height:6,borderRadius:'50%',background:'#22c55e',display:'inline-block',animation:'p 2s infinite'}}/>
                <span style={{fontSize:11,color:'#22c55e',fontWeight:600}}>Active</span>
                <style>{`@keyframes p{0%,100%{opacity:1}50%{opacity:0.3}}`}</style>
              </div>
            </div>
            <div style={{display:'flex',gap:'0.75rem',flexWrap:'wrap'}}>
              <div style={{textAlign:'center',background:'rgba(34,197,94,0.08)',border:'1px solid rgba(34,197,94,0.2)',borderRadius:12,padding:'12px 18px'}}>
                <div style={{fontSize:10,color:'#475569',marginBottom:4}}>Total Sent</div>
                <div style={{fontSize:18,fontWeight:700,color:'#ef4444'}}>-{fmtC(sent)}</div>
              </div>
              <div style={{textAlign:'center',background:'rgba(34,197,94,0.08)',border:'1px solid rgba(34,197,94,0.2)',borderRadius:12,padding:'12px 18px'}}>
                <div style={{fontSize:10,color:'#475569',marginBottom:4}}>Pending</div>
                <div style={{fontSize:18,fontWeight:700,color:'#f59e0b'}}>{pending.length}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'0.75rem',marginBottom:'1.5rem'}}>
          {[
            { icon:'💸', label:'Send Money',    color:'#4f6ef7', action:()=>nav('/transfer') },
            { icon:'📊', label:'Analytics',     color:'#a78bfa', action:()=>setTab('analytics') },
            { icon:'📋', label:'Transactions',  color:'#22c55e', action:()=>setTab('transactions') },
          ].map(a=>(
            <button key={a.label} onClick={a.action}
              style={{background:`${a.color}0e`,border:`1px solid ${a.color}28`,borderRadius:13,padding:'1rem',cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',gap:8,transition:'all .18s',color:'#fff'}}
              onMouseEnter={e=>{e.currentTarget.style.background=`${a.color}1c`;e.currentTarget.style.borderColor=`${a.color}55`;}}
              onMouseLeave={e=>{e.currentTarget.style.background=`${a.color}0e`;e.currentTarget.style.borderColor=`${a.color}28`;}}>
              <span style={{fontSize:24}}>{a.icon}</span>
              <span style={{fontSize:11,fontWeight:700,color:a.color}}>{a.label}</span>
            </button>
          ))}
        </div>

        {/* Tabs */}
        <div style={{display:'flex',gap:4,marginBottom:'1.25rem',background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:12,padding:4,width:'fit-content'}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{padding:'7px 18px',borderRadius:9,border:'none',cursor:'pointer',fontSize:12,fontWeight:600,transition:'all .15s',
                background:tab===t.id?'#1e2d40':'transparent',
                color:tab===t.id?'#4f6ef7':'#475569'}}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* ── OVERVIEW ── */}
        {tab==='overview' && (
          <>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'1rem',marginBottom:'1.25rem'}}>
              <StatCard icon="💰" label="Balance"     value={fmtC(bal)}         color="#22c55e"/>
              <StatCard icon="📤" label="Total Sent"  value={fmtC(sent)}        color="#4f6ef7" sub={`${txns.filter(t=>t.direction==='out').length} transfers`}/>
              <StatCard icon="⏳" label="Pending"     value={pending.length}     color="#f59e0b" sub="Awaiting admin review"/>
              <StatCard icon="✅" label="Approved"    value={approved.length}    color="#22c55e" sub={`${rejected.length} rejected`}/>
            </div>

            {/* Pending notice */}
            {pending.length > 0 && (
              <div style={{background:'rgba(245,158,11,0.08)',border:'1px solid rgba(245,158,11,0.25)',borderRadius:14,padding:'1rem 1.25rem',marginBottom:'1.25rem',display:'flex',alignItems:'center',gap:12}}>
                <span style={{fontSize:22}}>⏳</span>
                <div>
                  <div style={{fontSize:13,fontWeight:700,color:'#f59e0b'}}>You have {pending.length} pending transaction{pending.length>1?'s':''}</div>
                  <div style={{fontSize:11,color:'#64748b',marginTop:2}}>These are awaiting admin review. Your balance has been reserved.</div>
                </div>
                <button onClick={()=>setTab('transactions')} style={{marginLeft:'auto',background:'rgba(245,158,11,0.15)',border:'1px solid rgba(245,158,11,0.3)',color:'#f59e0b',borderRadius:8,padding:'6px 14px',cursor:'pointer',fontSize:11,fontWeight:700,flexShrink:0}}>View →</button>
              </div>
            )}

            {/* Chart + Recent split */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1.25rem',marginBottom:'1.25rem'}}>
              {/* Monthly bar */}
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>📊 Monthly Transfers</div>
                {txns.length === 0
                  ? <div style={{textAlign:'center',color:'#334155',padding:'3rem 0',fontSize:12}}>No transactions yet</div>
                  : <ResponsiveContainer width="100%" height={190}>
                      <BarChart data={monthlyData.filter(d=>d.Sent||d.Received)}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                        <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                        <YAxis tick={TX} axisLine={false} tickLine={false} tickFormatter={v=>`$${v>=1000?v/1000+'k':v}`}/>
                        <Tooltip content={<CTooltip/>}/>
                        <Bar dataKey="Sent"     fill="#4f6ef7" radius={[4,4,0,0]} maxBarSize={22}/>
                        <Bar dataKey="Received" fill="#22c55e" radius={[4,4,0,0]} maxBarSize={22}/>
                        <Legend wrapperStyle={{fontSize:10,color:'#94a3b8'}}/>
                      </BarChart>
                    </ResponsiveContainer>
                }
              </div>

              {/* Status donut */}
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>🍩 Transaction Status</div>
                {txns.length === 0
                  ? <div style={{textAlign:'center',color:'#334155',padding:'3rem 0',fontSize:12}}>No transactions yet</div>
                  : <div style={{display:'flex',alignItems:'center',gap:'1rem'}}>
                      <ResponsiveContainer width={150} height={150}>
                        <PieChart>
                          <Pie data={pieData} cx="50%" cy="50%" innerRadius={42} outerRadius={65} paddingAngle={4} dataKey="value">
                            {pieData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                          </Pie>
                          <Tooltip formatter={v=>[v,'Count']}/>
                        </PieChart>
                      </ResponsiveContainer>
                      <div>
                        {pieData.map(d=>(
                          <div key={d.name} style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
                            <div style={{width:9,height:9,borderRadius:'50%',background:d.color}}/>
                            <span style={{fontSize:12,color:'#94a3b8'}}>{d.name}</span>
                            <span style={{fontSize:14,fontWeight:700,color:'#e2e8f0',marginLeft:'auto',paddingLeft:12}}>{d.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                }
              </div>
            </div>

            {/* Recent */}
            <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1rem'}}>
                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0'}}>🕐 Recent Transactions</div>
                <button onClick={()=>setTab('transactions')} style={{background:'none',border:'none',color:'#4f6ef7',cursor:'pointer',fontSize:11,fontWeight:700}}>View all →</button>
              </div>
              {txns.length===0
                ? <div style={{textAlign:'center',color:'#334155',padding:'2rem',fontSize:12}}>
                    No transactions yet. <span style={{color:'#4f6ef7',cursor:'pointer'}} onClick={()=>nav('/transfer')}>Make your first transfer →</span>
                  </div>
                : txns.slice(0,5).map(t=><TRow key={t.id} t={t}/>)
              }
            </div>
          </>
        )}

        {/* ── TRANSACTIONS ── */}
        {tab==='transactions' && (
          <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1.25rem'}}>
              <div>
                <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0'}}>All Transactions ({txns.length})</div>
                <div style={{fontSize:11,color:'#475569',marginTop:2}}>Admin reviews each transfer before it clears</div>
              </div>
              <button onClick={()=>nav('/transfer')}
                style={{background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:10,padding:'9px 18px',cursor:'pointer',fontSize:12,fontWeight:700,display:'flex',alignItems:'center',gap:6,boxShadow:'0 4px 16px rgba(79,110,247,0.3)'}}>
                ＋ New Transfer
              </button>
            </div>

            {/* Status filter pills */}
            <div style={{display:'flex',gap:6,marginBottom:'1rem',flexWrap:'wrap'}}>
              {[
                {label:`All (${txns.length})`,       color:'#64748b'},
                {label:`Pending (${pending.length})`, color:'#f59e0b'},
                {label:`Approved (${approved.length})`,color:'#22c55e'},
                {label:`Rejected (${rejected.length})`,color:'#ef4444'},
              ].map(f=>(
                <span key={f.label} style={{fontSize:10,fontWeight:700,color:f.color,background:`${f.color}12`,border:`1px solid ${f.color}30`,padding:'3px 12px',borderRadius:20}}>
                  {f.label}
                </span>
              ))}
            </div>

            {txns.length===0
              ? <div style={{textAlign:'center',color:'#334155',padding:'3rem',fontSize:13}}>
                  No transactions yet. <span style={{color:'#4f6ef7',cursor:'pointer'}} onClick={()=>nav('/transfer')}>Send money →</span>
                </div>
              : txns.map(t=><TRow key={t.id} t={t}/>)
            }
          </div>
        )}

        {/* ── ANALYTICS ── */}
        {tab==='analytics' && (
          <>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'1rem',marginBottom:'1.25rem'}}>
              <StatCard icon="💸" label="Total Transferred" value={fmtC(sent)}      color="#4f6ef7" sub="All time"/>
              <StatCard icon="📦" label="Total Transactions" value={txns.length}      color="#a78bfa" sub="Submitted"/>
              <StatCard icon="📈" label="Approval Rate"      value={txns.length?Math.round((approved.length/txns.length)*100)+'%':'—'} color="#22c55e" sub="of your transfers"/>
            </div>

            {/* Monthly area */}
            <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem',marginBottom:'1.25rem'}}>
              <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:4}}>📈 Monthly Transaction Value</div>
              <div style={{fontSize:11,color:'#475569',marginBottom:'1rem'}}>How much you transferred each month</div>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={monthlyData}>
                  <defs>
                    <linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#4f6ef7" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#4f6ef7" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                  <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                  <YAxis tick={TX} axisLine={false} tickLine={false} tickFormatter={v=>v>=1000?`$${v/1000}k`:`$${v}`}/>
                  <Tooltip content={<CTooltip/>}/>
                  <Area type="monotone" dataKey="Sent" name="Sent" stroke="#4f6ef7" strokeWidth={2.5} fill="url(#sg)" dot={{r:4,fill:'#4f6ef7',stroke:'#080b12',strokeWidth:2}}/>
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Monthly count + Financial health */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1.25rem'}}>
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>📆 Transfers Per Month</div>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                    <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                    <YAxis tick={TX} axisLine={false} tickLine={false}/>
                    <Tooltip content={<CTooltip/>}/>
                    <Bar dataKey="Count" name="Transfers" fill="#a78bfa" radius={[4,4,0,0]} maxBarSize={26}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div style={{background:'linear-gradient(135deg,#0a1a10,#0d1a14)',border:'1px solid rgba(34,197,94,0.2)',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>💡 Account Health</div>
                {[
                  { label:'Approval Rate',   score: txns.length?Math.min(100,Math.round((approved.length/txns.length)*100)):100, color:'#22c55e' },
                  { label:'Activity Level',  score: Math.min(100, txns.length * 12),                                              color:'#4f6ef7' },
                  { label:'Account Standing',score: rejected.length===0?100:Math.max(40,100-rejected.length*15),                  color:'#a78bfa' },
                ].map(m=>(
                  <div key={m.label} style={{marginBottom:'1rem'}}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}>
                      <span style={{fontSize:12,color:'#94a3b8'}}>{m.label}</span>
                      <span style={{fontSize:12,fontWeight:700,color:m.color}}>{m.score}%</span>
                    </div>
                    <div style={{height:6,background:'#1e2435',borderRadius:4,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${m.score}%`,background:`linear-gradient(90deg,${m.color}88,${m.color})`,borderRadius:4,transition:'width .6s ease'}}/>
                    </div>
                  </div>
                ))}
                <div style={{marginTop:'1rem',padding:'10px',background:'rgba(34,197,94,0.06)',border:'1px solid rgba(34,197,94,0.15)',borderRadius:10,fontSize:11,color:'#475569',lineHeight:1.6}}>
                  All transfers are monitored by our compliance team. High-risk transfers may require additional review.
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
