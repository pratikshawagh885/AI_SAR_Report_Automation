import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { DB, subscribe } from '../data/store';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

const fmt = n => '$' + Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});

// ── Pill ──────────────────────────────────────────────────────────────────────
function Pill({ color, bg, border, children }) {
  return <span style={{fontSize:10,fontWeight:700,color,background:bg,border:`1px solid ${border}`,padding:'2px 10px',borderRadius:20,whiteSpace:'nowrap'}}>{children}</span>;
}

// ── Stat Card ─────────────────────────────────────────────────────────────────
function Stat({ icon, label, value, color='#4f6ef7', sub }) {
  return (
    <div style={{background:'#0d1018',border:`1px solid ${color}22`,borderRadius:14,padding:'1.1rem',position:'relative',overflow:'hidden'}}>
      <div style={{position:'absolute',top:0,right:0,width:60,height:60,background:`radial-gradient(circle at top right,${color}18,transparent 70%)`}}/>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
        <span style={{fontSize:10,color:'#475569',fontWeight:600,letterSpacing:0.5,textTransform:'uppercase'}}>{label}</span>
        <span style={{fontSize:18}}>{icon}</span>
      </div>
      <div style={{fontSize:26,fontWeight:700,color:'#fff',fontFamily:"'Sora',sans-serif"}}>{value}</div>
      {sub && <div style={{fontSize:10,color:'#475569',marginTop:3}}>{sub}</div>}
    </div>
  );
}

// ── Modal wrapper ─────────────────────────────────────────────────────────────
function Modal({ open, onClose, title, children, width=480 }) {
  if (!open) return null;
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.7)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:'1rem'}}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:'#0d1018',border:'1px solid #1e2435',borderRadius:18,padding:'1.75rem',width:'100%',maxWidth:width,maxHeight:'90vh',overflowY:'auto'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1.25rem'}}>
          <h3 style={{margin:0,fontSize:16,fontWeight:700,color:'#e2e8f0'}}>{title}</h3>
          <button onClick={onClose} style={{background:'transparent',border:'none',color:'#64748b',cursor:'pointer',fontSize:18,lineHeight:1}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Field ─────────────────────────────────────────────────────────────────────
function Field({ label, value, mono }) {
  return (
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'9px 0',borderBottom:'1px solid #1a1f2e'}}>
      <span style={{fontSize:12,color:'#64748b'}}>{label}</span>
      <span style={{fontSize:12,fontWeight:600,color:'#e2e8f0',fontFamily:mono?'monospace':undefined}}>{value}</span>
    </div>
  );
}

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const STATUS_CFG = {
  pending_review: { color:'#f59e0b', bg:'rgba(245,158,11,0.12)', label:'Pending Review' },
  cleared:        { color:'#22c55e', bg:'rgba(34,197,94,0.12)',  label:'Approved' },
  rejected:       { color:'#ef4444', bg:'rgba(239,68,68,0.12)', label:'Rejected' },
  flagged:        { color:'#ef4444', bg:'rgba(239,68,68,0.12)', label:'SAR Flagged' },
};

const TABS = [
  { id:'dashboard', icon:'📊', label:'Dashboard'    },
  { id:'users',     icon:'👥', label:'Users'         },
  { id:'txns',      icon:'💳', label:'Transactions'  },
  { id:'analysis',  icon:'📈', label:'Analysis'      },
  { id:'sars',      icon:'📋', label:'SAR Reports'   },
  { id:'audit',     icon:'📜', label:'Audit Log'     },
];

export default function AdminDashboard() {
  const { user, logout, addUser, removeUser, getAllUsers } = useAuth();
  const nav = useNavigate();
  const [tab,    setTab]   = useState('dashboard');
  const [txns,   setTxns]  = useState([]);
  const [sars,   setSars]  = useState([]);
  const [log,    setLog]   = useState([]);
  const [users,  setUsers] = useState([]);
  const [tick,   setTick]  = useState(0);

  // Modal states
  const [addModal,    setAddModal]    = useState(false);
  const [txnModal,    setTxnModal]    = useState(null);  // selected txn
  const [rejectModal, setRejectModal] = useState(null);  // txn id
  const [sarModal,    setSarModal]    = useState(null);  // selected sar
  const [rejectReason, setRejectReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState('');

  // Add user form
  const [newName,  setNewName]  = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPass,  setNewPass]  = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [addErr,   setAddErr]   = useState('');

  useEffect(() => {
    const refresh = () => {
      setTxns(DB.allUserTxns());
      setSars(DB.sars());
      setLog(DB.auditLog());
      setUsers(getAllUsers());
      setTick(t=>t+1);
    };
    refresh();
    return subscribe(refresh);
  }, []);

  const showToast = (msg) => { setToast(msg); setTimeout(()=>setToast(''),3000); };

  // Add user
  const handleAddUser = () => {
    setAddErr('');
    try {
      addUser({ name:newName, email:newEmail, pass:newPass, phone:newPhone });
      setUsers(getAllUsers());
      setNewName(''); setNewEmail(''); setNewPass(''); setNewPhone('');
      setAddModal(false);
      showToast('✅ User added successfully');
      DB._log('User Created', `Account created for ${newName} (${newEmail}) by Admin`, 'Admin');
    } catch(e) { setAddErr(e.message); }
  };

  // Approve txn
  const approve = (txnId) => {
    DB.approveTransaction(txnId, 'Admin');
    setTxnModal(null);
    showToast('✅ Transaction approved');
  };

  // Reject txn
  const reject = () => {
    if (!rejectReason.trim()) return;
    DB.rejectTransaction(rejectModal, rejectReason, 'Admin');
    setRejectModal(null); setTxnModal(null); setRejectReason('');
    showToast('❌ Transaction rejected & refunded');
  };

  // Flag as SAR
  const flagSAR = (txnId) => {
    DB.flagAsSAR(txnId, 'Admin');
    setTxnModal(null);
    showToast('🚨 SAR report created');
  };

  // Stats
  const pending  = txns.filter(t=>t.status==='pending_review');
  const approved = txns.filter(t=>t.status==='cleared');
  const rejected = txns.filter(t=>t.status==='rejected');
  const flagged  = txns.filter(t=>t.status==='flagged');
  const totalVol = txns.reduce((s,t)=>s+t.amount,0);

  // Monthly data
  const monthlyData = MONTHS.map((m,i) => {
    const mTxns = txns.filter(t => new Date(t.time).getMonth()===i);
    return {
      month: m,
      Volume:   mTxns.reduce((s,t)=>s+t.amount,0),
      Count:    mTxns.length,
      Approved: mTxns.filter(t=>t.status==='cleared').length,
      Rejected: mTxns.filter(t=>t.status==='rejected').length,
    };
  });

  // Per-user analytics
  const userAnalytics = users.map(u => {
    const ut = txns.filter(t=>t.accountId===u.accountId);
    return { ...u, txnCount: ut.length, totalSent: ut.reduce((s,t)=>s+t.amount,0), pending: ut.filter(t=>t.status==='pending_review').length };
  }).sort((a,b)=>b.totalSent-a.totalSent);

  const TT = { contentStyle:{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:8,fontSize:11} };
  const TX = { fill:'#475569',fontSize:10 };

  return (
    <div style={{minHeight:'100vh',background:'#080b12',fontFamily:"'DM Sans',sans-serif",color:'#fff',display:'flex'}}>

      {/* Toast */}
      {toast && (
        <div style={{position:'fixed',top:20,right:20,background:'#1a1d27',border:'1px solid #2d3147',borderRadius:12,padding:'12px 20px',fontSize:13,fontWeight:600,color:'#e2e8f0',zIndex:9999,boxShadow:'0 8px 32px rgba(0,0,0,0.4)',animation:'slideIn .3s ease'}}>
          {toast}
          <style>{`@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}`}</style>
        </div>
      )}

      {/* Sidebar */}
      <aside style={{width:220,background:'#0a0d14',borderRight:'1px solid #1a1f2e',display:'flex',flexDirection:'column',flexShrink:0,height:'100vh',position:'sticky',top:0}}>
        {/* Logo */}
        <div style={{padding:'16px 14px',borderBottom:'1px solid #1a1f2e',display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:34,height:34,background:'linear-gradient(135deg,#4f6ef7,#818cf8)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,boxShadow:'0 0 18px rgba(79,110,247,0.35)'}}>⚡</div>
          <div>
            <div style={{fontFamily:"'Sora',sans-serif",fontSize:13,fontWeight:700,color:'#fff'}}>SAR Nexus</div>
            <div style={{fontSize:9,color:'#4f6ef7',fontWeight:600,letterSpacing:0.8}}>ADMIN PANEL</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{flex:1,padding:'10px 8px',overflowY:'auto'}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{display:'flex',alignItems:'center',gap:10,width:'100%',padding:'9px 10px',borderRadius:9,border:`1px solid ${tab===t.id?'rgba(79,110,247,0.3)':'transparent'}`,background:tab===t.id?'rgba(79,110,247,0.15)':'transparent',color:tab===t.id?'#818cf8':'#475569',cursor:'pointer',fontSize:12,fontWeight:tab===t.id?700:400,marginBottom:2,textAlign:'left',transition:'all .15s'}}>
              <span style={{fontSize:14}}>{t.icon}</span>{t.label}
              {t.id==='txns' && pending.length>0 && <span style={{marginLeft:'auto',background:'#ef4444',color:'#fff',borderRadius:10,fontSize:9,fontWeight:700,padding:'1px 6px'}}>{pending.length}</span>}
            </button>
          ))}
        </nav>

        {/* User info */}
        <div style={{borderTop:'1px solid #1a1f2e',padding:'12px 10px'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
            <div style={{width:28,height:28,borderRadius:8,background:'rgba(79,110,247,0.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#4f6ef7'}}>AD</div>
            <div>
              <div style={{fontSize:11,fontWeight:600,color:'#e2e8f0'}}>Administrator</div>
              <div style={{fontSize:9,color:'#4f6ef7',fontWeight:700}}>ADMIN</div>
            </div>
          </div>
          <button onClick={()=>{logout();nav('/login');}} style={{display:'flex',alignItems:'center',gap:6,width:'100%',background:'transparent',border:'1px solid #1e2435',borderRadius:7,color:'#ef4444',cursor:'pointer',padding:'6px 8px',fontSize:11}}>
            🚪 Sign out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main style={{flex:1,overflowY:'auto',height:'100vh'}}>
        <header style={{background:'#0a0d14',borderBottom:'1px solid #1a1f2e',padding:'12px 24px',display:'flex',justifyContent:'space-between',alignItems:'center',position:'sticky',top:0,zIndex:50}}>
          <div>
            <h2 style={{margin:0,fontSize:16,fontWeight:700,color:'#fff'}}>{TABS.find(t=>t.id===tab)?.icon} {TABS.find(t=>t.id===tab)?.label}</h2>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <span style={{width:6,height:6,borderRadius:'50%',background:'#22c55e',display:'inline-block',animation:'pulse 2s infinite'}}/>
            <span style={{fontSize:11,color:'#475569'}}>Live monitoring</span>
            <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}`}</style>
          </div>
        </header>

        <div style={{padding:'1.5rem'}}>

          {/* ═══════ DASHBOARD TAB ═══════ */}
          {tab==='dashboard' && (
            <>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'1rem',marginBottom:'1.5rem'}}>
                <Stat icon="👥" label="Total Users"     value={users.length}         color="#4f6ef7" sub="Registered accounts"/>
                <Stat icon="⏳" label="Pending Review"  value={pending.length}        color="#f59e0b" sub="Need your action"/>
                <Stat icon="💰" label="Total Volume"    value={'$'+Math.round(totalVol/1000)+'k'} color="#22c55e" sub="All user transfers"/>
                <Stat icon="🚨" label="SAR Reports"     value={sars.length}           color="#ef4444" sub="Flagged transactions"/>
              </div>

              {/* Pending Transactions — action required */}
              <div style={{background:'#0d1018',border:'1px solid rgba(245,158,11,0.2)',borderRadius:16,padding:'1.25rem',marginBottom:'1.25rem'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1rem'}}>
                  <div>
                    <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0'}}>⏳ Pending Transactions</div>
                    <div style={{fontSize:11,color:'#475569',marginTop:2}}>These transactions need your approval, rejection, or SAR filing</div>
                  </div>
                  {pending.length>0 && <span style={{background:'rgba(245,158,11,0.15)',color:'#f59e0b',border:'1px solid rgba(245,158,11,0.3)',borderRadius:20,padding:'3px 12px',fontSize:11,fontWeight:700}}>{pending.length} pending</span>}
                </div>

                {pending.length===0
                  ? <div style={{textAlign:'center',padding:'2rem',color:'#475569',fontSize:13}}>✅ No pending transactions — all clear!</div>
                  : <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                      <thead><tr style={{borderBottom:'1px solid #1a1f2e'}}>
                        {['User','Amount','To','Type','Risk','Time','Actions'].map(h=>(
                          <th key={h} style={{textAlign:'left',padding:'8px 10px',color:'#475569',fontWeight:600,fontSize:11}}>{h}</th>
                        ))}
                      </tr></thead>
                      <tbody>
                        {pending.map(t=>(
                          <tr key={t.id} style={{borderBottom:'1px solid #0d1018',transition:'background .15s'}}
                            onMouseEnter={e=>e.currentTarget.style.background='#1a1f2e'}
                            onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                            <td style={{padding:'10px 10px',color:'#22c55e',fontWeight:600}}>{t.userName}</td>
                            <td style={{padding:'10px 10px',color:'#fff',fontWeight:700}}>{fmt(t.amount)}</td>
                            <td style={{padding:'10px 10px',color:'#94a3b8',maxWidth:120,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.counterparty}</td>
                            <td style={{padding:'10px 10px',color:'#64748b'}}>{t.type}</td>
                            <td style={{padding:'10px 10px'}}>
                              <span style={{fontSize:11,fontWeight:700,color:t.riskScore>=50?'#ef4444':t.riskScore>=25?'#f59e0b':'#22c55e',background:t.riskScore>=50?'rgba(239,68,68,0.12)':t.riskScore>=25?'rgba(245,158,11,0.12)':'rgba(34,197,94,0.12)',border:`1px solid ${t.riskScore>=50?'rgba(239,68,68,0.3)':t.riskScore>=25?'rgba(245,158,11,0.3)':'rgba(34,197,94,0.3)'}`,padding:'2px 8px',borderRadius:6}}>
                                {t.riskScore}
                              </span>
                            </td>
                            <td style={{padding:'10px 10px',color:'#475569',whiteSpace:'nowrap'}}>{new Date(t.time).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</td>
                            <td style={{padding:'10px 10px'}}>
                              <div style={{display:'flex',gap:5}}>
                                <button onClick={()=>approve(t.id)} style={{background:'rgba(34,197,94,0.15)',border:'1px solid rgba(34,197,94,0.3)',color:'#22c55e',borderRadius:6,padding:'4px 10px',cursor:'pointer',fontSize:11,fontWeight:700}}>✓ Approve</button>
                                <button onClick={()=>{ setRejectModal(t.id); setTxnModal(null); }} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#ef4444',borderRadius:6,padding:'4px 10px',cursor:'pointer',fontSize:11,fontWeight:700}}>✕ Reject</button>
                                <button onClick={()=>flagSAR(t.id)} style={{background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.25)',color:'#f59e0b',borderRadius:6,padding:'4px 10px',cursor:'pointer',fontSize:11,fontWeight:700}}>⚑ SAR</button>
                                <button onClick={()=>setTxnModal(t)} style={{background:'rgba(79,110,247,0.1)',border:'1px solid rgba(79,110,247,0.2)',color:'#818cf8',borderRadius:6,padding:'4px 10px',cursor:'pointer',fontSize:11}}>Detail</button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                }
              </div>

              {/* Quick user stats */}
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>👥 Registered Users Overview</div>
                {users.length===0
                  ? <div style={{textAlign:'center',padding:'2rem',color:'#475569',fontSize:13}}>No users yet. <button onClick={()=>{setTab('users');setAddModal(true);}} style={{background:'none',border:'none',color:'#4f6ef7',cursor:'pointer',fontSize:13}}>Add first user →</button></div>
                  : <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:'0.75rem'}}>
                      {users.map(u=>(
                        <div key={u.id} style={{background:'#080b12',border:'1px solid #1e2435',borderRadius:12,padding:'0.9rem'}}>
                          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:8}}>
                            <div style={{width:32,height:32,borderRadius:9,background:'rgba(34,197,94,0.15)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,color:'#22c55e'}}>{u.avatar}</div>
                            <div>
                              <div style={{fontSize:12,fontWeight:700,color:'#e2e8f0'}}>{u.name}</div>
                              <div style={{fontSize:10,color:'#475569'}}>{u.email}</div>
                            </div>
                          </div>
                          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
                            <div style={{background:'rgba(34,197,94,0.06)',borderRadius:7,padding:'5px 8px',textAlign:'center'}}>
                              <div style={{fontSize:14,fontWeight:700,color:'#22c55e'}}>{txns.filter(t=>t.accountId===u.accountId).length}</div>
                              <div style={{fontSize:9,color:'#475569'}}>Transactions</div>
                            </div>
                            <div style={{background:'rgba(79,110,247,0.06)',borderRadius:7,padding:'5px 8px',textAlign:'center'}}>
                              <div style={{fontSize:14,fontWeight:700,color:'#4f6ef7'}}>{txns.filter(t=>t.accountId===u.accountId&&t.status==='pending_review').length}</div>
                              <div style={{fontSize:9,color:'#475569'}}>Pending</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                }
              </div>
            </>
          )}

          {/* ═══════ USERS TAB ═══════ */}
          {tab==='users' && (
            <>
              <div style={{display:'flex',justifyContent:'flex-end',marginBottom:'1rem'}}>
                <button onClick={()=>setAddModal(true)}
                  style={{background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:10,padding:'10px 22px',cursor:'pointer',fontSize:13,fontWeight:700,display:'flex',alignItems:'center',gap:8,boxShadow:'0 4px 20px rgba(79,110,247,0.3)'}}>
                  ＋ Add New User
                </button>
              </div>

              {users.length===0
                ? (
                  <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'4rem',textAlign:'center'}}>
                    <div style={{fontSize:40,marginBottom:'1rem'}}>👤</div>
                    <div style={{fontSize:15,fontWeight:700,color:'#e2e8f0',marginBottom:'0.5rem'}}>No users yet</div>
                    <div style={{fontSize:13,color:'#475569',marginBottom:'1.5rem'}}>Add your first user to get started</div>
                    <button onClick={()=>setAddModal(true)} style={{background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:10,padding:'10px 24px',cursor:'pointer',fontSize:13,fontWeight:700}}>Add User</button>
                  </div>
                )
                : (
                  <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,overflow:'hidden'}}>
                    <table style={{width:'100%',borderCollapse:'collapse',fontSize:13}}>
                      <thead><tr style={{background:'#080b12',borderBottom:'1px solid #1a1f2e'}}>
                        {['User','Email','Account ID','Balance','Transactions','Pending','Joined','Actions'].map(h=>(
                          <th key={h} style={{textAlign:'left',padding:'12px 14px',color:'#475569',fontWeight:600,fontSize:11}}>{h}</th>
                        ))}
                      </tr></thead>
                      <tbody>
                        {users.map(u=>{
                          const ut = txns.filter(t=>t.accountId===u.accountId);
                          const bal = DB.getBalance(u.accountId);
                          return (
                            <tr key={u.id} style={{borderBottom:'1px solid #0d1018',transition:'background .15s'}}
                              onMouseEnter={e=>e.currentTarget.style.background='#1a1f2e'}
                              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                              <td style={{padding:'12px 14px'}}>
                                <div style={{display:'flex',alignItems:'center',gap:10}}>
                                  <div style={{width:32,height:32,borderRadius:9,background:'rgba(34,197,94,0.15)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,color:'#22c55e'}}>{u.avatar}</div>
                                  <span style={{fontSize:13,fontWeight:600,color:'#e2e8f0'}}>{u.name}</span>
                                </div>
                              </td>
                              <td style={{padding:'12px 14px',color:'#94a3b8'}}>{u.email}</td>
                              <td style={{padding:'12px 14px',color:'#64748b',fontFamily:'monospace',fontSize:11}}>{u.accountId}</td>
                              <td style={{padding:'12px 14px',color:'#22c55e',fontWeight:700}}>{fmt(bal)}</td>
                              <td style={{padding:'12px 14px',color:'#e2e8f0'}}>{ut.length}</td>
                              <td style={{padding:'12px 14px'}}>
                                {ut.filter(t=>t.status==='pending_review').length > 0
                                  ? <Pill color="#f59e0b" bg="rgba(245,158,11,0.12)" border="rgba(245,158,11,0.25)">{ut.filter(t=>t.status==='pending_review').length} Pending</Pill>
                                  : <Pill color="#22c55e" bg="rgba(34,197,94,0.1)" border="rgba(34,197,94,0.2)">Clear</Pill>
                                }
                              </td>
                              <td style={{padding:'12px 14px',color:'#475569',fontSize:11}}>{new Date(u.createdAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</td>
                              <td style={{padding:'12px 14px'}}>
                                <button onClick={()=>{ if(window.confirm(`Remove user ${u.name}?`)) { removeUser(u.id); setUsers(getAllUsers()); showToast('User removed'); }}}
                                  style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.2)',color:'#ef4444',borderRadius:7,padding:'4px 12px',cursor:'pointer',fontSize:11,fontWeight:600}}>
                                  Remove
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )
              }
            </>
          )}

          {/* ═══════ TRANSACTIONS TAB ═══════ */}
          {tab==='txns' && (
            <>
              <div style={{display:'flex',gap:'0.75rem',marginBottom:'1rem',flexWrap:'wrap'}}>
                {[
                  {label:'All',       count:txns.length,           color:'#64748b'},
                  {label:'Pending',   count:pending.length,         color:'#f59e0b'},
                  {label:'Approved',  count:approved.length,        color:'#22c55e'},
                  {label:'Rejected',  count:rejected.length,        color:'#ef4444'},
                  {label:'SAR Filed', count:flagged.length,         color:'#a78bfa'},
                ].map(f=>(
                  <div key={f.label} style={{background:'#0d1018',border:`1px solid ${f.color}25`,borderRadius:10,padding:'8px 16px',display:'flex',gap:8,alignItems:'center'}}>
                    <span style={{fontSize:16,fontWeight:700,color:f.color}}>{f.count}</span>
                    <span style={{fontSize:11,color:'#64748b'}}>{f.label}</span>
                  </div>
                ))}
              </div>

              {txns.length===0
                ? <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'4rem',textAlign:'center',color:'#475569',fontSize:13}}>No user transactions yet. Transactions will appear here when users transfer money.</div>
                : (
                  <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,overflow:'hidden'}}>
                    <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                      <thead><tr style={{background:'#080b12',borderBottom:'1px solid #1a1f2e'}}>
                        {['Txn ID','User','To','Amount','Type','Risk','Status','Date','Actions'].map(h=>(
                          <th key={h} style={{textAlign:'left',padding:'11px 12px',color:'#475569',fontWeight:600,fontSize:11}}>{h}</th>
                        ))}
                      </tr></thead>
                      <tbody>
                        {txns.map(t=>{
                          const sc = STATUS_CFG[t.status]||STATUS_CFG.pending_review;
                          return (
                            <tr key={t.id} style={{borderBottom:'1px solid #0d1018',cursor:'pointer',transition:'background .15s'}}
                              onMouseEnter={e=>e.currentTarget.style.background='#1a1f2e'}
                              onMouseLeave={e=>e.currentTarget.style.background='transparent'}
                              onClick={()=>setTxnModal(t)}>
                              <td style={{padding:'11px 12px',color:'#818cf8',fontFamily:'monospace',fontSize:10}}>{t.id.slice(0,16)}…</td>
                              <td style={{padding:'11px 12px',color:'#22c55e',fontWeight:600}}>{t.userName}</td>
                              <td style={{padding:'11px 12px',color:'#94a3b8',maxWidth:130,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.counterparty}</td>
                              <td style={{padding:'11px 12px',color:'#fff',fontWeight:700}}>{fmt(t.amount)}</td>
                              <td style={{padding:'11px 12px',color:'#64748b'}}>{t.type}</td>
                              <td style={{padding:'11px 12px'}}>
                                <span style={{fontSize:11,fontWeight:700,color:t.riskScore>=50?'#ef4444':t.riskScore>=25?'#f59e0b':'#22c55e'}}>{t.riskScore}</span>
                              </td>
                              <td style={{padding:'11px 12px'}}><span style={{fontSize:10,fontWeight:700,color:sc.color,background:sc.bg,border:`1px solid ${sc.color}30`,padding:'2px 9px',borderRadius:20}}>{sc.label}</span></td>
                              <td style={{padding:'11px 12px',color:'#475569',whiteSpace:'nowrap',fontSize:10}}>{new Date(t.time).toLocaleDateString('en-US',{month:'short',day:'numeric'})}</td>
                              <td style={{padding:'11px 12px'}} onClick={e=>e.stopPropagation()}>
                                {t.status==='pending_review' && (
                                  <div style={{display:'flex',gap:4}}>
                                    <button onClick={()=>approve(t.id)} style={{background:'rgba(34,197,94,0.15)',border:'1px solid rgba(34,197,94,0.3)',color:'#22c55e',borderRadius:5,padding:'3px 8px',cursor:'pointer',fontSize:10,fontWeight:700}}>✓</button>
                                    <button onClick={()=>setRejectModal(t.id)} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#ef4444',borderRadius:5,padding:'3px 8px',cursor:'pointer',fontSize:10,fontWeight:700}}>✕</button>
                                    <button onClick={()=>flagSAR(t.id)} style={{background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.25)',color:'#f59e0b',borderRadius:5,padding:'3px 8px',cursor:'pointer',fontSize:10,fontWeight:700}}>SAR</button>
                                  </div>
                                )}
                                {t.status!=='pending_review' && <span style={{fontSize:10,color:'#334155'}}>{t.adminBy||'—'}</span>}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )
              }
            </>
          )}

          {/* ═══════ ANALYSIS TAB ═══════ */}
          {tab==='analysis' && (
            <>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:'1rem',marginBottom:'1.5rem'}}>
                <Stat icon="💸" label="Total Volume"  value={'$'+Math.round(totalVol/1000)+'k'} color="#4f6ef7"/>
                <Stat icon="✅" label="Approved"      value={approved.length} color="#22c55e"/>
                <Stat icon="❌" label="Rejected"      value={rejected.length} color="#ef4444"/>
                <Stat icon="🚨" label="SAR Reports"   value={flagged.length}  color="#f59e0b"/>
              </div>

              {/* Monthly volume */}
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem',marginBottom:'1.25rem'}}>
                <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0',marginBottom:4}}>📊 Monthly Transaction Volume</div>
                <div style={{fontSize:11,color:'#475569',marginBottom:'1rem'}}>Total value of all user transfers per month</div>
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                    <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                    <YAxis tick={TX} axisLine={false} tickLine={false} tickFormatter={v=>v>=1000?`$${v/1000}k`:`$${v}`}/>
                    <Tooltip {...TT} formatter={v=>['$'+v.toLocaleString(),'Volume']}/>
                    <Bar dataKey="Volume" fill="#4f6ef7" radius={[5,5,0,0]} maxBarSize={32}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1.25rem',marginBottom:'1.25rem'}}>
                {/* Monthly count */}
                <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                  <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>📈 Monthly Transaction Count</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={monthlyData}>
                      <defs>
                        <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                      <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                      <YAxis tick={TX} axisLine={false} tickLine={false}/>
                      <Tooltip {...TT}/>
                      <Area type="monotone" dataKey="Count" stroke="#22c55e" strokeWidth={2} fill="url(#cg)"/>
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Approved vs Rejected */}
                <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                  <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>✅ Approved vs ❌ Rejected</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1a1f2e" vertical={false}/>
                      <XAxis dataKey="month" tick={TX} axisLine={false} tickLine={false}/>
                      <YAxis tick={TX} axisLine={false} tickLine={false}/>
                      <Tooltip {...TT}/>
                      <Bar dataKey="Approved" fill="#22c55e" radius={[4,4,0,0]} maxBarSize={20}/>
                      <Bar dataKey="Rejected" fill="#ef4444" radius={[4,4,0,0]} maxBarSize={20}/>
                      <Legend wrapperStyle={{fontSize:10,color:'#94a3b8'}}/>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Per-user analysis */}
              <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'1.25rem'}}>
                <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0',marginBottom:'1rem'}}>👤 Per-User Transaction Analysis</div>
                {userAnalytics.length===0
                  ? <div style={{textAlign:'center',color:'#475569',padding:'2rem',fontSize:13}}>No user data yet</div>
                  : userAnalytics.map((u,i)=>{
                      const pct = totalVol>0 ? Math.round((u.totalSent/totalVol)*100) : 0;
                      return (
                        <div key={u.id} style={{marginBottom:'1rem',padding:'12px',background:'#080b12',borderRadius:12,border:'1px solid #1a1f2e'}}>
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                            <div style={{display:'flex',alignItems:'center',gap:10}}>
                              <div style={{width:32,height:32,borderRadius:9,background:'rgba(34,197,94,0.15)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,color:'#22c55e',fontSize:12}}>{u.avatar}</div>
                              <div>
                                <div style={{fontSize:13,fontWeight:700,color:'#e2e8f0'}}>{u.name}</div>
                                <div style={{fontSize:10,color:'#475569'}}>{u.email}</div>
                              </div>
                            </div>
                            <div style={{display:'flex',gap:'1rem',textAlign:'right'}}>
                              <div><div style={{fontSize:14,fontWeight:700,color:'#4f6ef7'}}>{u.txnCount}</div><div style={{fontSize:9,color:'#475569'}}>TRANSACTIONS</div></div>
                              <div><div style={{fontSize:14,fontWeight:700,color:'#22c55e'}}>{fmt(u.totalSent)}</div><div style={{fontSize:9,color:'#475569'}}>TOTAL SENT</div></div>
                              {u.pending>0 && <div><div style={{fontSize:14,fontWeight:700,color:'#f59e0b'}}>{u.pending}</div><div style={{fontSize:9,color:'#475569'}}>PENDING</div></div>}
                            </div>
                          </div>
                          <div style={{display:'flex',alignItems:'center',gap:10}}>
                            <div style={{flex:1,height:5,background:'#1a1f2e',borderRadius:3,overflow:'hidden'}}>
                              <div style={{height:'100%',width:`${pct}%`,background:'linear-gradient(90deg,#4f6ef7,#22c55e)',borderRadius:3,transition:'width .5s'}}/>
                            </div>
                            <span style={{fontSize:10,color:'#475569',flexShrink:0}}>{pct}% of total</span>
                          </div>
                        </div>
                      );
                    })
                }
              </div>
            </>
          )}

          {/* ═══════ SAR REPORTS TAB ═══════ */}
          {tab==='sars' && (
            <>
              {sars.length===0
                ? <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,padding:'4rem',textAlign:'center',color:'#475569',fontSize:13}}>No SAR reports yet. Flag a transaction as SAR from the Transactions tab.</div>
                : (
                  <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
                    {sars.map(s=>(
                      <div key={s.id} style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:14,padding:'1.25rem',cursor:'pointer',transition:'border-color .2s'}}
                        onMouseEnter={e=>e.currentTarget.style.borderColor='#4f6ef755'}
                        onMouseLeave={e=>e.currentTarget.style.borderColor='#1a1f2e'}
                        onClick={()=>setSarModal(s)}>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
                          <div>
                            <div style={{fontSize:14,fontWeight:700,color:'#e2e8f0',fontFamily:'monospace',marginBottom:4}}>{s.id}</div>
                            <div style={{fontSize:11,color:'#475569'}}>Account: {s.accountId} · {s.type} · Created by {s.createdBy}</div>
                          </div>
                          <div style={{display:'flex',gap:8,alignItems:'center'}}>
                            <span style={{fontSize:10,fontWeight:700,color:'#ef4444',background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.3)',padding:'3px 10px',borderRadius:20}}>Risk: {s.riskScore}</span>
                            <span style={{fontSize:10,fontWeight:700,color: s.status==='filed'?'#818cf8':s.status==='approved'?'#22c55e':s.status==='rejected'?'#ef4444':'#f59e0b',background: s.status==='filed'?'rgba(129,140,248,0.12)':s.status==='approved'?'rgba(34,197,94,0.12)':s.status==='rejected'?'rgba(239,68,68,0.12)':'rgba(245,158,11,0.12)',padding:'3px 10px',borderRadius:20}}>
                              {s.status.replace('_',' ').toUpperCase()}
                            </span>
                          </div>
                        </div>
                        <div style={{fontSize:12,color:'#64748b',lineHeight:1.6,display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical',overflow:'hidden'}}>{s.narrative}</div>
                        {s.status==='pending_review' && (
                          <div style={{display:'flex',gap:8,marginTop:'0.75rem'}} onClick={e=>e.stopPropagation()}>
                            <button onClick={()=>{ DB.approveSAR(s.id,'Admin'); showToast('SAR approved'); }} style={{background:'rgba(34,197,94,0.15)',border:'1px solid rgba(34,197,94,0.3)',color:'#22c55e',borderRadius:7,padding:'5px 14px',cursor:'pointer',fontSize:11,fontWeight:700}}>✓ Approve SAR</button>
                            <button onClick={()=>{ DB.rejectSAR(s.id,'Insufficient evidence','Admin'); showToast('SAR rejected'); }} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#ef4444',borderRadius:7,padding:'5px 14px',cursor:'pointer',fontSize:11,fontWeight:700}}>✕ Reject SAR</button>
                          </div>
                        )}
                        {s.status==='approved' && !s.filedAt && (
                          <div style={{marginTop:'0.75rem'}} onClick={e=>e.stopPropagation()}>
                            <button onClick={()=>{ DB.fileSAR(s.id,'Admin'); showToast('SAR filed on-chain!'); }} style={{background:'rgba(129,140,248,0.15)',border:'1px solid rgba(129,140,248,0.3)',color:'#818cf8',borderRadius:7,padding:'5px 14px',cursor:'pointer',fontSize:11,fontWeight:700}}>⛓ File On-Chain</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )
              }
            </>
          )}

          {/* ═══════ AUDIT LOG TAB ═══════ */}
          {tab==='audit' && (
            <div style={{background:'#0d1018',border:'1px solid #1a1f2e',borderRadius:16,overflow:'hidden'}}>
              {log.length===0
                ? <div style={{textAlign:'center',padding:'4rem',color:'#475569',fontSize:13}}>Audit log is empty</div>
                : (
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                    <thead><tr style={{background:'#080b12',borderBottom:'1px solid #1a1f2e'}}>
                      {['Time','Action','Detail','By'].map(h=>(
                        <th key={h} style={{textAlign:'left',padding:'12px 14px',color:'#475569',fontWeight:600,fontSize:11}}>{h}</th>
                      ))}
                    </tr></thead>
                    <tbody>
                      {log.map((l,i)=>(
                        <tr key={i} style={{borderBottom:'1px solid #0d1018'}}>
                          <td style={{padding:'10px 14px',color:'#475569',fontSize:10,whiteSpace:'nowrap'}}>{new Date(l.ts).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</td>
                          <td style={{padding:'10px 14px',color:'#818cf8',fontWeight:600,whiteSpace:'nowrap'}}>{l.action}</td>
                          <td style={{padding:'10px 14px',color:'#94a3b8',maxWidth:400,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{l.detail}</td>
                          <td style={{padding:'10px 14px',color:'#22c55e',fontWeight:600}}>{l.user}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )
              }
            </div>
          )}
        </div>
      </main>

      {/* ── Add User Modal ── */}
      <Modal open={addModal} onClose={()=>{setAddModal(false);setAddErr('');}} title="➕ Add New User">
        {[
          {label:'FULL NAME *',     val:newName,  set:setNewName,  type:'text',     ph:'e.g. John Smith'},
          {label:'EMAIL *',         val:newEmail, set:setNewEmail, type:'email',    ph:'user@email.com'},
          {label:'PASSWORD *',      val:newPass,  set:setNewPass,  type:'password', ph:'Min 6 characters'},
          {label:'PHONE (OPTIONAL)',val:newPhone, set:setNewPhone, type:'tel',      ph:'+1-555-000-0000'},
        ].map(f=>(
          <div key={f.label} style={{marginBottom:'1rem'}}>
            <label style={{fontSize:10,color:'#64748b',fontWeight:700,letterSpacing:0.5,display:'block',marginBottom:5}}>{f.label}</label>
            <input value={f.val} onChange={e=>f.set(e.target.value)} type={f.type} placeholder={f.ph}
              style={{width:'100%',background:'#080b12',border:'1px solid #1e2435',color:'#e2e8f0',borderRadius:8,padding:'10px 12px',fontSize:13,boxSizing:'border-box',outline:'none',fontFamily:"'DM Sans',sans-serif"}}
              onFocus={e=>e.target.style.borderColor='#4f6ef7'}
              onBlur={e=>e.target.style.borderColor='#1e2435'}
            />
          </div>
        ))}
        {addErr && <div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.3)',borderRadius:8,padding:'10px',color:'#fca5a5',fontSize:12,marginBottom:'1rem'}}>⚠ {addErr}</div>}
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>{setAddModal(false);setAddErr('');}} style={{flex:1,background:'transparent',border:'1px solid #1e2435',color:'#64748b',borderRadius:9,padding:11,cursor:'pointer',fontSize:13}}>Cancel</button>
          <button onClick={handleAddUser} style={{flex:2,background:'linear-gradient(135deg,#4f6ef7,#818cf8)',border:'none',color:'#fff',borderRadius:9,padding:11,cursor:'pointer',fontSize:13,fontWeight:700}}>Create User Account</button>
        </div>
      </Modal>

      {/* ── Transaction Detail Modal ── */}
      <Modal open={!!txnModal} onClose={()=>setTxnModal(null)} title="💳 Transaction Detail">
        {txnModal && (
          <>
            <Field label="Transaction ID" value={txnModal.id}          mono/>
            <Field label="User"           value={txnModal.userName}/>
            <Field label="Account ID"     value={txnModal.accountId}   mono/>
            <Field label="Amount"         value={fmt(txnModal.amount)}/>
            <Field label="To"             value={txnModal.counterparty}/>
            <Field label="Type"           value={txnModal.type}/>
            <Field label="Risk Score"     value={`${txnModal.riskScore} / 100`}/>
            <Field label="Status"         value={(STATUS_CFG[txnModal.status]||{}).label||txnModal.status}/>
            <Field label="Date"           value={new Date(txnModal.time).toLocaleString()}/>
            {txnModal.notes && <Field label="User Note" value={txnModal.notes}/>}
            {txnModal.adminBy && <Field label="Reviewed by" value={txnModal.adminBy}/>}
            {txnModal.rejectionReason && <Field label="Rejection Reason" value={txnModal.rejectionReason}/>}
            {Object.keys(txnModal.signals||{}).length>0 && (
              <div style={{marginTop:'1rem'}}>
                <div style={{fontSize:10,color:'#64748b',fontWeight:700,marginBottom:8}}>🚨 RISK SIGNALS</div>
                {Object.entries(txnModal.signals).map(([k,v])=>(
                  <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'5px 0',borderBottom:'1px solid #1a1f2e'}}>
                    <span style={{fontSize:11,color:'#94a3b8'}}>{k}</span>
                    <span style={{fontSize:11,fontWeight:700,color:'#f59e0b'}}>+{v}</span>
                  </div>
                ))}
              </div>
            )}
            {txnModal.status==='pending_review' && (
              <div style={{display:'flex',gap:8,marginTop:'1.25rem'}}>
                <button onClick={()=>approve(txnModal.id)} style={{flex:1,background:'rgba(34,197,94,0.15)',border:'1px solid rgba(34,197,94,0.3)',color:'#22c55e',borderRadius:9,padding:10,cursor:'pointer',fontSize:12,fontWeight:700}}>✓ Approve</button>
                <button onClick={()=>{ setRejectModal(txnModal.id); setTxnModal(null); }} style={{flex:1,background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#ef4444',borderRadius:9,padding:10,cursor:'pointer',fontSize:12,fontWeight:700}}>✕ Reject</button>
                <button onClick={()=>flagSAR(txnModal.id)} style={{flex:1,background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.25)',color:'#f59e0b',borderRadius:9,padding:10,cursor:'pointer',fontSize:12,fontWeight:700}}>⚑ SAR</button>
              </div>
            )}
          </>
        )}
      </Modal>

      {/* ── Reject Modal ── */}
      <Modal open={!!rejectModal} onClose={()=>{setRejectModal(null);setRejectReason('');}} title="✕ Reject Transaction">
        <p style={{color:'#64748b',fontSize:13,marginTop:0}}>Provide a reason for rejection. The amount will be refunded to the user.</p>
        <textarea value={rejectReason} onChange={e=>setRejectReason(e.target.value)} placeholder="e.g. Suspicious destination account, policy violation..."
          rows={4} style={{width:'100%',background:'#080b12',border:'1px solid #1e2435',color:'#e2e8f0',borderRadius:9,padding:'10px 12px',fontSize:13,boxSizing:'border-box',outline:'none',resize:'vertical',fontFamily:"'DM Sans',sans-serif'",marginBottom:'1rem'}}
          onFocus={e=>e.target.style.borderColor='#ef4444'}
          onBlur={e=>e.target.style.borderColor='#1e2435'}
        />
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>{setRejectModal(null);setRejectReason('');}} style={{flex:1,background:'transparent',border:'1px solid #1e2435',color:'#64748b',borderRadius:9,padding:11,cursor:'pointer',fontSize:13}}>Cancel</button>
          <button onClick={reject} disabled={!rejectReason.trim()} style={{flex:2,background: rejectReason.trim()?'rgba(239,68,68,0.2)':'#1e2435',border:`1px solid ${rejectReason.trim()?'rgba(239,68,68,0.4)':'#2d3147'}`,color:rejectReason.trim()?'#ef4444':'#475569',borderRadius:9,padding:11,cursor:rejectReason.trim()?'pointer':'not-allowed',fontSize:13,fontWeight:700}}>Reject & Refund</button>
        </div>
      </Modal>

      {/* ── SAR Detail Modal ── */}
      <Modal open={!!sarModal} onClose={()=>setSarModal(null)} title="📋 SAR Report Detail" width={560}>
        {sarModal && (
          <>
            <Field label="SAR ID"      value={sarModal.id}          mono/>
            <Field label="Account"     value={sarModal.accountId}   mono/>
            <Field label="Amount"      value={fmt(sarModal.amount)}/>
            <Field label="Risk Score"  value={`${sarModal.riskScore}/100`}/>
            <Field label="Status"      value={sarModal.status.replace('_',' ').toUpperCase()}/>
            <Field label="Created By"  value={sarModal.createdBy}/>
            <Field label="Created At"  value={new Date(sarModal.createdAt).toLocaleString()}/>
            {sarModal.approvedBy && <Field label="Approved By" value={`${sarModal.approvedBy} on ${new Date(sarModal.approvedAt).toLocaleDateString()}`}/>}
            {sarModal.blockchainHash && <Field label="Blockchain Hash" value={sarModal.blockchainHash.slice(0,20)+'…'} mono/>}
            <div style={{marginTop:'1rem'}}>
              <div style={{fontSize:10,color:'#64748b',fontWeight:700,marginBottom:8}}>NARRATIVE</div>
              <div style={{background:'#080b12',border:'1px solid #1a1f2e',borderRadius:9,padding:'12px',fontSize:12,color:'#94a3b8',lineHeight:1.7,whiteSpace:'pre-wrap'}}>{sarModal.narrative}</div>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}
