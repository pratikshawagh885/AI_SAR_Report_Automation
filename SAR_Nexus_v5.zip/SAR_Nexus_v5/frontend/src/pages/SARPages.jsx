import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { DB, ACCOUNTS, mlScore, subscribe } from '../data/store';
import { useAuth } from '../context/AuthContext';
import { Card, RiskBadge, SBadge, Btn, Modal, PHdr, Toast, TInput, TSelect, TArea, SigBar, DataRow, riskColor, riskLabel } from '../components/UI';

const TT = { contentStyle:{background:'#1a1d27',border:'1px solid #3d4261',borderRadius:9,fontSize:11} };
const TX = { fill:'#475569',fontSize:11 };

// ════════════════════ ADD TRANSACTION ════════════════════════════════════════
export function AddTransaction() {
  const { user, can } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({
    accountId:'ACC-4421', amount:'', type:'Wire Transfer',
    country:'USA', counterparty:'', velocity:'1', offHours:false
  });
  const [preview, setPreview] = useState(null);
  const [result, setResult]   = useState(null);
  const [toast, setToast]     = useState(null);

  if (!can('addTxn')) return (
    <div style={{padding:'3rem',textAlign:'center'}}>
      <div style={{fontSize:40,marginBottom:12}}>⛔</div>
      <h2 style={{color:'#ef4444',fontFamily:"'Sora',sans-serif"}}>Access Denied</h2>
      <p style={{color:'#64748b',fontSize:13}}>Only Analysts and Admins can add transactions.</p>
      <Btn ghost onClick={()=>nav('/')} style={{marginTop:'1rem'}}>← Back to Dashboard</Btn>
    </div>
  );

  const upd = (k,v) => {
    const next = {...form,[k]:v};
    setForm(next);
    if (next.amount && parseFloat(next.amount)>0) {
      const acc = ACCOUNTS.find(a=>a.id===next.accountId)||{avgMonthly:10000};
      const fake = { amount:parseFloat(next.amount), velocity:parseInt(next.velocity)||1, country:next.country, offHours:next.offHours, counterparty:next.counterparty };
      setPreview(mlScore(fake,acc));
    } else setPreview(null);
  };

  const submit = e => {
    e.preventDefault();
    if (!form.amount || parseFloat(form.amount)<=0) return;
    const txn = DB.addTransaction({
      accountId:   form.accountId,
      amount:      parseFloat(form.amount),
      type:        form.type,
      country:     form.country,
      counterparty:form.counterparty||'Unknown Entity',
      velocity:    parseInt(form.velocity)||1,
      offHours:    form.offHours,
      isRound:     false,
    });
    setResult(txn);
    setToast({msg:`✅ ${txn.id} submitted — Risk Score: ${txn.riskScore}/100`,type:txn.riskScore>=80?'warn':'ok'});
  };

  const ACCOPTS = ACCOUNTS.map(a=>({v:a.id,l:`${a.id} — ${a.name} (${a.country})`}));
  const TYPES   = ['Wire Transfer','Cash Deposit','ACH','SWIFT',"Int'l Transfer",'Crypto Transfer','Money Order'];
  const CTRIES  = ['USA','UK','India','Germany','France','Brazil','Mexico','Cayman Islands','Panama','Belize','BVI','Vanuatu','Seychelles'];

  return (
    <div>
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)}/>}
      <PHdr title="Add Transaction" sub="Manually submit a transaction — ML analyses it in real time as you fill the form"/>

      {!result ? (
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1.25rem'}}>
          {/* Form */}
          <Card>
            <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:'1rem'}}>Transaction Details</div>
            <form onSubmit={submit}>
              <TSelect label="Account" value={form.accountId} onChange={e=>upd('accountId',e.target.value)} options={ACCOPTS}/>
              <TInput  label="Amount (USD)" type="number" min="1" step="0.01" value={form.amount} onChange={e=>upd('amount',e.target.value)} placeholder="e.g. 9800"/>
              <TSelect label="Transaction Type" value={form.type} onChange={e=>upd('type',e.target.value)} options={TYPES}/>
              <TSelect label="Country / Jurisdiction" value={form.country} onChange={e=>upd('country',e.target.value)} options={CTRIES}/>
              <TInput  label="Counterparty name" value={form.counterparty} onChange={e=>upd('counterparty',e.target.value)} placeholder="e.g. Offshore Holdings Ltd"/>
              <TInput  label="Velocity — how many transactions in past 24 hours?" type="number" min="1" max="50" value={form.velocity} onChange={e=>upd('velocity',e.target.value)}/>
              <label style={{display:'flex',alignItems:'center',gap:8,fontSize:12,color:'#94a3b8',marginBottom:'1.2rem',cursor:'pointer'}}>
                <input type="checkbox" checked={form.offHours} onChange={e=>upd('offHours',e.target.checked)} style={{width:14,height:14}}/>
                Off-hours transaction (sent between 12am–6am)
              </label>
              <button type="submit" style={{width:'100%',background:'#4f6ef7',color:'#fff',border:'none',borderRadius:9,padding:'11px',fontSize:13,fontWeight:700,cursor:'pointer'}}>
                Submit & Analyse with ML →
              </button>
            </form>
          </Card>

          {/* Live ML preview */}
          <Card>
            <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:'1rem'}}>⚡ Live ML Risk Preview</div>
            {!preview ? (
              <div style={{textAlign:'center',padding:'3rem 1rem',color:'#475569'}}>
                <div style={{fontSize:32,marginBottom:8}}>🧠</div>
                <div style={{fontSize:13}}>Fill in the form</div>
                <div style={{fontSize:11,marginTop:4}}>Risk score updates in real time</div>
              </div>
            ) : (
              <div>
                <div style={{textAlign:'center',marginBottom:'1.5rem'}}>
                  <div style={{fontSize:11,color:'#64748b',marginBottom:8}}>Predicted risk score</div>
                  <RiskBadge score={preview.score} large/>
                  <div style={{fontSize:13,marginTop:10,color:riskColor(preview.score),fontWeight:700}}>
                    {preview.score>=80?'🔴 HIGH — Will be auto-flagged':preview.score>=55?'🟡 MEDIUM — Manual review required':'🟢 LOW — Will be auto-cleared'}
                  </div>
                </div>
                {Object.keys(preview.signals).length>0 ? (
                  <div>
                    <div style={{fontSize:11,color:'#64748b',marginBottom:10}}>Detected risk signals:</div>
                    {Object.entries(preview.signals).map(([k,v])=><SigBar key={k} label={k} score={v}/>)}
                  </div>
                ) : (
                  <div style={{textAlign:'center',color:'#6ee7b7',fontSize:12,padding:'1rem',background:'rgba(34,197,94,.08)',borderRadius:9}}>
                    ✅ No suspicious signals detected for current input
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      ) : (
        /* Result screen */
        <Card style={{textAlign:'center',padding:'2.5rem'}}>
          <div style={{fontSize:48,marginBottom:12}}>{result.riskScore>=80?'🚨':result.riskScore>=55?'⚠️':'✅'}</div>
          <h2 style={{fontFamily:"'Sora',sans-serif",color:'#fff',marginBottom:8}}>{result.id} Submitted</h2>
          <div style={{display:'flex',gap:'0.7rem',justifyContent:'center',alignItems:'center',marginBottom:'1rem',flexWrap:'wrap'}}>
            <RiskBadge score={result.riskScore} large/>
            <SBadge status={result.status}/>
          </div>
          <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.5rem'}}>
            {result.status==='flagged'?'⚠ This transaction was automatically flagged for compliance review.':
             result.status==='review'?'This transaction has been queued for manual review.':
             '✅ This transaction cleared ML analysis with no suspicious signals.'}
          </div>
          {Object.keys(result.signals).length>0 && (
            <div style={{background:'#1e2535',borderRadius:10,padding:'0.75rem',margin:'1rem auto',maxWidth:360,textAlign:'left'}}>
              {Object.entries(result.signals).map(([k,v])=><SigBar key={k} label={k} score={v}/>)}
            </div>
          )}
          <div style={{display:'flex',gap:'0.7rem',justifyContent:'center',flexWrap:'wrap',marginTop:'1rem'}}>
            <Btn onClick={()=>nav(`/transactions/${result.id}`)}>View Full Analysis →</Btn>
            <Btn ghost onClick={()=>{setResult(null);setPreview(null);setForm({accountId:'ACC-4421',amount:'',type:'Wire Transfer',country:'USA',counterparty:'',velocity:'1',offHours:false});}}>
              Add Another Transaction
            </Btn>
          </div>
        </Card>
      )}
    </div>
  );
}

// ════════════════════ SAR REPORTS LIST ════════════════════════════════════════
export function SARReports() {
  const nav = useNavigate();
  const [, tick] = useState(0);
  const [filter, setFilter] = useState('all');

  useEffect(()=>subscribe(()=>tick(t=>t+1)),[]);

  const sars = DB.sars();
  const shown = filter==='all'?sars:sars.filter(s=>s.status===filter);
  const counts = {};
  ['draft','pending_review','approved','filed','rejected'].forEach(s=>{ counts[s]=sars.filter(x=>x.status===s).length; });

  return (
    <div>
      <PHdr title="SAR Reports" sub="AI-generated narratives · Role-reviewed · Blockchain-filed · Audit-logged"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:'0.6rem',marginBottom:'1rem'}}>
        {[['draft','📝','Draft'],['pending_review','⏳','Pending'],['approved','✅','Approved'],['filed','⛓','Filed'],['rejected','❌','Rejected']].map(([s,i,l])=>(
          <button key={s} onClick={()=>setFilter(filter===s?'all':s)}
            style={{background:filter===s?'rgba(79,110,247,.2)':'#1a1d27',border:`1px solid ${filter===s?'#4f6ef7':'#2d3147'}`,borderRadius:10,padding:'0.6rem',cursor:'pointer',textAlign:'center',transition:'all .15s'}}>
            <div style={{fontSize:18}}>{i}</div>
            <div style={{fontSize:12,fontWeight:600,color:'#fff'}}>{counts[s]||0}</div>
            <div style={{fontSize:10,color:'#64748b'}}>{l}</div>
          </button>
        ))}
      </div>
      <Card style={{padding:0,overflow:'hidden'}}>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
          <thead>
            <tr style={{background:'#1e2535',borderBottom:'1px solid #2d3147'}}>
              {['SAR ID','Account','Amount','Risk','Type','Status','Created By','Blockchain','Action'].map(h=>(
                <th key={h} style={{textAlign:'left',padding:'10px 12px',color:'#64748b',fontWeight:500,whiteSpace:'nowrap'}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {shown.map(s=>(
              <tr key={s.id} style={{borderBottom:'1px solid #1a1d27',transition:'background .1s'}}
                onMouseEnter={e=>e.currentTarget.style.background='#1e2535'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{padding:'10px 12px',color:'#818cf8',fontFamily:'monospace',whiteSpace:'nowrap'}}>{s.id}</td>
                <td style={{padding:'10px 12px'}}>
                  <div style={{fontSize:12,color:'#e2e8f0'}}>{ACCOUNTS.find(a=>a.id===s.accountId)?.name||s.accountId}</div>
                  <div style={{fontSize:10,color:'#475569'}}>{s.accountId}</div>
                </td>
                <td style={{padding:'10px 12px',color:'#fff',fontWeight:700}}>${s.amount.toLocaleString()}</td>
                <td style={{padding:'10px 12px'}}><RiskBadge score={s.riskScore}/></td>
                <td style={{padding:'10px 12px',color:'#64748b',fontSize:11}}>{s.type}</td>
                <td style={{padding:'10px 12px'}}><SBadge status={s.status}/></td>
                <td style={{padding:'10px 12px',color:'#64748b'}}>{s.createdBy}</td>
                <td style={{padding:'10px 12px',fontFamily:'monospace',fontSize:10,color:'#4f6ef7'}}>
                  {s.blockchainHash?s.blockchainHash.slice(0,14)+'...':'—'}
                </td>
                <td style={{padding:'10px 12px'}}><Btn sm onClick={()=>nav(`/reports/${s.id}`)}>Review →</Btn></td>
              </tr>
            ))}
          </tbody>
        </table>
        {shown.length===0 && <div style={{textAlign:'center',padding:'3rem',color:'#475569',fontSize:13}}>No SARs match filter</div>}
      </Card>
    </div>
  );
}

// ════════════════════ SAR DETAIL — full workflow ══════════════════════════════
export function SARDetail() {
  const { id } = useParams();
  const { user, can } = useAuth();
  const nav = useNavigate();
  const [, tick] = useState(0);
  const [toast, setToast]         = useState(null);
  const [rejectModal,setRejectModal]= useState(false);
  const [rejectReason,setRejectReason]= useState('');
  const [warnModal,setWarnModal]   = useState(false);
  const [warnMsg,setWarnMsg]       = useState('');
  const [emailModal,setEmailModal] = useState(false);
  const [emailSub,setEmailSub]     = useState('');

  useEffect(()=>subscribe(()=>tick(t=>t+1)),[]);

  const sar = DB.sars().find(s=>s.id===id);
  if (!sar) return <div style={{color:'#ef4444',padding:'2rem'}}>SAR {id} not found</div>;

  const acc     = ACCOUNTS.find(a=>a.id===sar.accountId);
  const sigBars = Object.entries(sar.signals||{}).map(([k,v])=>({name:k,score:v})).sort((a,b)=>b.score-a.score);
  const toast$  = (m,t='ok') => setToast({msg:m,type:t});

  const doApprove = () => {
    DB.approveSAR(sar.id, user.name);
    toast$(`✅ SAR ${sar.id} approved by ${user.name}`);
  };
  const doReject = () => {
    if (!rejectReason.trim()) return;
    DB.rejectSAR(sar.id, rejectReason, user.name);
    toast$('❌ SAR rejected and recorded in audit log','warn');
    setRejectModal(false); setRejectReason('');
  };
  const doFile = () => {
    const hash = DB.fileSAR(sar.id, user.name);
    toast$(`⛓ Filed on-chain! Hash: ${hash.slice(0,18)}...`);
  };
  const doWarn = () => {
    if (!warnMsg.trim()) return;
    DB.sendWarning(sar.accountId, warnMsg, user.name);
    toast$(`⚠ Warning issued to ${acc?.name}`,'warn');
    setWarnModal(false); setWarnMsg('');
  };
  const doEmail = () => {
    if (!emailSub.trim()) return;
    DB.sendEmail(sar.accountId, emailSub, '', user.name);
    toast$(`📧 Email sent to ${acc?.email}`);
    setEmailModal(false); setEmailSub('');
  };

  return (
    <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)}/>}

      {/* Header */}
      <div>
        <button onClick={()=>nav('/reports')} style={{fontSize:11,color:'#64748b',background:'none',border:'none',cursor:'pointer',marginBottom:6,padding:0}}>← Back to SAR Reports</button>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:'0.7rem'}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
              <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:18,fontWeight:600,color:'#fff',margin:0}}>{sar.id}</h1>
              <RiskBadge score={sar.riskScore} large/>
              <SBadge status={sar.status}/>
            </div>
            <p style={{fontSize:12,color:'#64748b',marginTop:5,marginBottom:0}}>
              {acc?.name} ({sar.accountId}) · {sar.type} · ${sar.amount.toLocaleString()} · {sar.jurisdiction}
            </p>
          </div>

          {/* Action buttons — each button only shows when allowed by role AND status */}
          <div style={{display:'flex',gap:'0.5rem',flexWrap:'wrap'}}>
            {/* APPROVE: officer/admin, when pending_review or draft */}
            {can('approveSAR') && (sar.status==='pending_review'||sar.status==='draft') && (
              <Btn color="#22c55e" onClick={doApprove}>✅ Approve SAR</Btn>
            )}
            {/* REJECT: officer/admin, when pending or draft */}
            {can('rejectSAR') && (sar.status==='pending_review'||sar.status==='draft') && (
              <Btn danger onClick={()=>setRejectModal(true)}>❌ Reject SAR</Btn>
            )}
            {/* FILE ON-CHAIN: officer/admin, only when approved */}
            {can('fileSAR') && sar.status==='approved' && (
              <Btn color="#6366f1" onClick={doFile}>⛓ File On Blockchain</Btn>
            )}
            {/* WARN: officer/admin always */}
            {can('sendWarning') && (
              <Btn color="#f59e0b" onClick={()=>setWarnModal(true)}>⚠ Issue Warning</Btn>
            )}
            {/* EMAIL: officer/admin always */}
            {can('sendWarning') && (
              <Btn color="#8b5cf6" onClick={()=>setEmailModal(true)}>📧 Email Account</Btn>
            )}
          </div>
        </div>
      </div>

      {/* Status explanation bar */}
      {sar.status==='pending_review' && (
        <div style={{background:'rgba(245,158,11,.1)',border:'1px solid rgba(245,158,11,.3)',borderRadius:10,padding:'0.7rem 1rem',fontSize:12,color:'#fcd34d'}}>
          ⏳ This SAR is waiting for an Officer or Admin to review it. Use the <strong>Approve</strong> or <strong>Reject</strong> buttons above.
        </div>
      )}
      {sar.status==='approved' && !sar.blockchainHash && (
        <div style={{background:'rgba(99,102,241,.1)',border:'1px solid rgba(99,102,241,.3)',borderRadius:10,padding:'0.7rem 1rem',fontSize:12,color:'#a5b4fc'}}>
          ✅ Approved — ready to be <strong>filed on blockchain</strong>. Click "File On Blockchain" to create the immutable record.
        </div>
      )}
      {sar.status==='rejected' && (
        <div style={{background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.3)',borderRadius:10,padding:'0.7rem 1rem',fontSize:12,color:'#fca5a5'}}>
          ❌ Rejected by {sar.rejectedBy} — Reason: "{sar.rejectionReason}"
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:'1rem'}}>
        {/* AI Narrative */}
        <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
          <Card>
            <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:10}}>🧠 AI-Generated SAR Narrative</div>
            <div style={{background:'#0f1620',borderRadius:9,padding:'1rem',fontFamily:'monospace',fontSize:12,color:'#cbd5e1',lineHeight:1.75,border:'1px solid #1e2d42',whiteSpace:'pre-wrap'}}>
              {sar.narrative}
            </div>
          </Card>

          {/* Blockchain confirmation */}
          {sar.blockchainHash && (
            <Card style={{background:'#0a1628',border:'1px solid #1e3a5f'}}>
              <div style={{fontSize:13,fontWeight:600,color:'#6ee7b7',marginBottom:10}}>⛓ Blockchain Record Confirmed</div>
              <DataRow label="Transaction Hash" value={sar.blockchainHash} mono/>
              <DataRow label="Filed by"         value={sar.filedBy}/>
              <DataRow label="Filed at"         value={new Date(sar.filedAt).toLocaleString()}/>
              <DataRow label="Network"          value="Ethereum Sepolia"/>
              <div style={{marginTop:8,fontSize:11,color:'#475569'}}>This record is immutable and cannot be altered after filing.</div>
            </Card>
          )}

          {/* Warnings / emails log */}
          {(sar.warnings?.length>0 || sar.emails?.length>0) && (
            <Card>
              <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:10}}>📋 Actions Taken on Account</div>
              {sar.warnings?.map((w,i)=><div key={i} style={{fontSize:12,color:'#fcd34d',marginBottom:4}}>⚠ {w}</div>)}
              {sar.emails?.map((e,i)=><div key={i} style={{fontSize:12,color:'#a5b4fc',marginBottom:4}}>📧 {e}</div>)}
            </Card>
          )}
        </div>

        {/* Right panel */}
        <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
          <Card>
            <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:10}}>📊 Risk Signal Breakdown</div>
            {sigBars.length===0
              ? <div style={{color:'#6ee7b7',fontSize:12,textAlign:'center',padding:'1rem'}}>✅ No signals</div>
              : sigBars.map(s=><SigBar key={s.name} label={s.name} score={s.score}/>)
            }
            <div style={{borderTop:'1px solid #2d3147',marginTop:10,paddingTop:10,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontSize:11,color:'#64748b'}}>Total score</span>
              <RiskBadge score={sar.riskScore} large/>
            </div>
          </Card>

          <Card>
            <div style={{fontSize:13,fontWeight:500,color:'#e2e8f0',marginBottom:10}}>📋 Report Info</div>
            <DataRow label="SAR ID"      value={sar.id} mono/>
            <DataRow label="Account"     value={sar.accountId}/>
            <DataRow label="Created by"  value={sar.createdBy}/>
            <DataRow label="Created"     value={new Date(sar.createdAt).toLocaleDateString()}/>
            <DataRow label="Jurisdiction"value={sar.jurisdiction}/>
            <DataRow label="Status"      value={<SBadge status={sar.status}/>}/>
            {sar.approvedBy && <DataRow label="Approved by" value={sar.approvedBy}/>}
            {sar.rejectedBy && <DataRow label="Rejected by" value={sar.rejectedBy}/>}
          </Card>
        </div>
      </div>

      {/* Modals */}
      <Modal open={rejectModal} onClose={()=>setRejectModal(false)} title="❌ Reject SAR — Provide Reason">
        <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.8rem'}}>The rejection reason is required and will be recorded in the audit log.</div>
        <TArea label="Rejection reason" value={rejectReason} onChange={e=>setRejectReason(e.target.value)}
          placeholder="e.g. Insufficient evidence of suspicious intent. The counterparty is a verified business partner with established transaction history."/>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setRejectModal(false)}>Cancel</Btn>
          <Btn danger onClick={doReject}>❌ Confirm Rejection</Btn>
        </div>
      </Modal>

      <Modal open={warnModal} onClose={()=>setWarnModal(false)} title="⚠ Issue Warning to Account">
        <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.8rem'}}>Warning will be sent to <strong style={{color:'#fff'}}>{acc?.name}</strong> and logged in the audit trail.</div>
        <TArea label="Warning message" value={warnMsg} onChange={e=>setWarnMsg(e.target.value)}
          placeholder="e.g. Your account has been flagged under FinCEN compliance guidelines. Please contact your relationship manager within 48 hours..."/>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setWarnModal(false)}>Cancel</Btn>
          <Btn color="#f59e0b" onClick={doWarn}>⚠ Issue Warning</Btn>
        </div>
      </Modal>

      <Modal open={emailModal} onClose={()=>setEmailModal(false)} title="📧 Send Email to Account Holder">
        <div style={{fontSize:12,color:'#94a3b8',marginBottom:'0.8rem'}}>To: <strong style={{color:'#fff'}}>{acc?.email}</strong></div>
        <TInput label="Subject" value={emailSub} onChange={e=>setEmailSub(e.target.value)}
          placeholder="e.g. Compliance Notice — Account Review Required"/>
        <div style={{display:'flex',gap:'0.5rem',justifyContent:'flex-end'}}>
          <Btn ghost onClick={()=>setEmailModal(false)}>Cancel</Btn>
          <Btn color="#8b5cf6" onClick={doEmail}>📧 Send Email Notice</Btn>
        </div>
      </Modal>
    </div>
  );
}
