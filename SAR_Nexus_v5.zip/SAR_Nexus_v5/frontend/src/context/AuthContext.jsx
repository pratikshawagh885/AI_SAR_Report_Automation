import React, { createContext, useContext, useState } from 'react';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

function loadUsers() { try { return JSON.parse(localStorage.getItem('sar_users')) || []; } catch { return []; } }
function saveUsers(list) { localStorage.setItem('sar_users', JSON.stringify(list)); }

const ADMIN = { id:'admin', name:'Administrator', email:'admin@sar.io', pass:'admin123', role:'admin', avatar:'AD', color:'#4f6ef7' };

export function AuthProvider({ children }) {
  const [user,  setUser]  = useState(() => { try { return JSON.parse(localStorage.getItem('sar_u')); } catch { return null; } });
  const [users, setUsers] = useState(loadUsers);

  const login = (email, pass) => {
    if (email === ADMIN.email && pass === ADMIN.pass) {
      const safe = { id:ADMIN.id, name:ADMIN.name, email:ADMIN.email, role:'admin', avatar:ADMIN.avatar, color:ADMIN.color };
      localStorage.setItem('sar_u', JSON.stringify(safe));
      setUser(safe); return safe;
    }
    const all = loadUsers();
    const u = all.find(x => x.email === email && x.pass === pass);
    if (!u) throw new Error('Invalid email or password');
    const safe = { id:u.id, name:u.name, email:u.email, role:'user', avatar:u.avatar, color:'#22c55e', accountId:u.accountId };
    localStorage.setItem('sar_u', JSON.stringify(safe));
    setUser(safe); return safe;
  };

  const logout = () => { localStorage.removeItem('sar_u'); setUser(null); };

  // Shared create logic (used by admin panel AND self-register)
  const _createUser = ({ name, email, pass, phone }) => {
    if (!name || !email || !pass) throw new Error('Name, email and password are required');
    if (pass.length < 6)         throw new Error('Password must be at least 6 characters');
    const all = loadUsers();
    if (all.find(u => u.email === email)) throw new Error('Email is already registered');
    const id = 'USR-' + Date.now();
    const accountId = 'ACC-' + id;
    const initials = name.trim().split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
    const newUser = { id, name:name.trim(), email:email.trim(), pass, phone:phone||'', avatar:initials, accountId, createdAt:new Date().toISOString(), balance:10000 };
    const updated = [...all, newUser];
    saveUsers(updated);
    setUsers(updated);
    return newUser;
  };

  // Admin adds user manually
  const addUser = (data) => _createUser(data);

  // User self-registers → auto login
  const register = (data) => {
    const newUser = _createUser(data);
    const safe = { id:newUser.id, name:newUser.name, email:newUser.email, role:'user', avatar:newUser.avatar, color:'#22c55e', accountId:newUser.accountId };
    localStorage.setItem('sar_u', JSON.stringify(safe));
    setUser(safe);
    return safe;
  };

  const removeUser = (id) => {
    const updated = loadUsers().filter(u => u.id !== id);
    saveUsers(updated);
    setUsers(updated);
  };

  const getAllUsers = () => loadUsers();

  const can = (action) => {
    const CAPS = {
      admin: ['view','addTxn','createSAR','approveSAR','rejectSAR','fileSAR','auditLog','manageUsers','viewAllTxn'],
      user:  ['view','transfer','viewOwnTxn'],
    };
    return (CAPS[user?.role] || []).includes(action);
  };

  return <Ctx.Provider value={{ user, login, logout, register, can, addUser, removeUser, getAllUsers, users }}>{children}</Ctx.Provider>;
}

// ── Seed helper (imported lazily to avoid circular deps) ─────────────────────
// Called from Login.jsx after successful auth
export function seedIfNew(accountId, userName) {
  // Dynamic import to avoid circular dependency
  import('../data/store').then(({ DB }) => {
    DB.seedUserTransactions(accountId, userName);
  });
}
