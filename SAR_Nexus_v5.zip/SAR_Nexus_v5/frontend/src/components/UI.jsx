import React, { useState, useEffect } from 'react';

// ── Color helpers ────────────────────────────────────────────────────────────
export const riskColor = r => r>=80?'#ef4444':r>=55?'#f59e0b':'#22c55e';
export const riskBg    = r => r>=80?'rgba(239,68,68,.15)':r>=55?'rgba(245,158,11,.15)':'rgba(34,197,94,.15)';
export const riskLabel = r => r>=80?'HIGH RISK':r>=55?'MEDIUM RISK':'LOW RISK';

const STATUS = {
  flagged:        { bg:'rgba(239,68,68,.15)',  fg:'#fca5a5', icon:'🔴', text:'Flagged'         },
  review:         { bg:'rgba(245,158,11,.15)', fg:'#fcd34d', icon:'🟡', text:'Under Review'    },
  cleared:        { bg:'rgba(34,197,94,.15)',  fg:'#6ee7b7', icon:'🟢', text:'Cleared'         },
  draft:          { bg:'rgba(99,102,241,.15)', fg:'#a5b4fc', icon:'📝', text:'Draft'           },
  pending_review: { bg:'rgba(245,158,11,.15)', fg:'#fcd34d', icon:'⏳', text:'Pending Review'  },
  approved:       { bg:'rgba(34,197,94,.15)',  fg:'#6ee7b7', icon:'✅', text:'Approved'        },
  filed:          { bg:'rgba(99,102,241,.15)', fg:'#818cf8', icon:'⛓', text:'Filed On-Chain'  },
  rejected:       { bg:'rgba(239,68,68,.15)',  fg:'#fca5a5', icon:'❌', text:'Rejected'        },
  watchlist:      { bg:'rgba(139,92,246,.15)', fg:'#c4b5fd', icon:'👁', text:'Watchlist'       },
  normal:         { bg:'rgba(100,116,139,.15)',fg:'#94a3b8', icon:'●',  text:'Normal'          },
  high:           { bg:'rgba(239,68,68,.15)',  fg:'#fca5a5', icon:'🔴', text:'High Risk'       },
  medium:         { bg:'rgba(245,158,11,.15)', fg:'#fcd34d', icon:'🟡', text:'Medium Risk'     },
  low:            { bg:'rgba(34,197,94,.15)',  fg:'#6ee7b7', icon:'🟢', text:'Low Risk'        },
};

// ── Risk badge ──────────────────────────────────────────────────────────────
export function RiskBadge({ score, large }) {
  const c = riskColor(score);
  return <span style={{background:`${c}22`,color:c,border:`1px solid ${c}44`,
    padding:large?'4px 14px':'2px 8px',borderRadius:6,fontSize:large?16:11,fontWeight:700}}>{score}</span>;
}

// ── Status badge ─────────────────────────────────────────────────────────────
export function SBadge({ status }) {
  const s = STATUS[status] || STATUS.normal;
  return <span style={{background:s.bg,color:s.fg,padding:'2px 10px',borderRadius:20,fontSize:11,fontWeight:600,border:`1px solid ${s.fg}33`,whiteSpace:'nowrap'}}>
    {s.icon} {s.text}
  </span>;
}

// ── Card ──────────────────────────────────────────────────────────────────────
export function Card({ children, style={}, onClick }) {
  return <div onClick={onClick} style={{background:'#1a1d27',border:'1px solid #2d3147',borderRadius:14,padding:'1.1rem',cursor:onClick?'pointer':'default',...style}}>{children}</div>;
}

// ── Stat card ─────────────────────────────────────────────────────────────────
export function Stat({ label, value, sub, icon, accent='#4f6ef7' }) {
  return <div style={{background:'#1a1d27',border:`1px solid ${accent}33`,borderRadius:14,padding:'1rem'}}>
    <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
      <span style={{fontSize:11,color:'#64748b'}}>{label}</span>
      {icon && <span style={{fontSize:18}}>{icon}</span>}
    </div>
    <div style={{fontSize:26,fontWeight:700,color:'#fff',fontFamily:"'Sora',sans-serif"}}>{value}</div>
    {sub && <div style={{fontSize:11,color:'#64748b',marginTop:3}}>{sub}</div>}
  </div>;
}

// ── Button ────────────────────────────────────────────────────────────────────
export function Btn({ children, onClick, color='#4f6ef7', ghost, danger, disabled, sm, full, style={} }) {
  const [hover, setHover] = useState(false);
  const bg   = disabled?'#2d3147':ghost?'transparent':danger?'#7f1d1d':color;
  const fg   = ghost?'#94a3b8':danger?'#fca5a5':'#fff';
  const bord = ghost?'1px solid #3d4261':danger?'1px solid #991b1b':'none';
  return <button disabled={disabled} onClick={onClick}
    onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
    style={{background:hover&&!disabled?`${bg}cc`:bg,color:fg,border:bord,borderRadius:9,
      padding:sm?'5px 12px':'8px 18px',fontSize:sm?11:13,fontWeight:600,
      cursor:disabled?'not-allowed':'pointer',opacity:disabled?0.5:1,whiteSpace:'nowrap',
      transition:'all .15s',width:full?'100%':'auto',...style}}>
    {children}
  </button>;
}

// ── Text input ────────────────────────────────────────────────────────────────
const INPUT_STYLE = { background:'#232635',border:'1px solid #3d4261',color:'#e2e8f0',borderRadius:9,
  padding:'9px 13px',fontSize:13,boxSizing:'border-box',width:'100%',outline:'none',fontFamily:"'DM Sans',sans-serif" };

export function TInput({ label, ...props }) {
  return <div style={{marginBottom:'0.8rem'}}>
    {label && <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>{label}</div>}
    <input style={INPUT_STYLE} {...props}/>
  </div>;
}
export function TSelect({ label, options=[], ...props }) {
  return <div style={{marginBottom:'0.8rem'}}>
    {label && <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>{label}</div>}
    <select style={{...INPUT_STYLE,cursor:'pointer'}} {...props}>
      {options.map(o=><option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}
    </select>
  </div>;
}
export function TArea({ label, ...props }) {
  return <div style={{marginBottom:'0.8rem'}}>
    {label && <div style={{fontSize:11,color:'#94a3b8',marginBottom:5}}>{label}</div>}
    <textarea style={{...INPUT_STYLE,resize:'vertical',minHeight:90}} {...props}/>
  </div>;
}

// ── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, width=500 }) {
  if (!open) return null;
  return <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.75)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:'1rem'}}>
    <div style={{background:'#1a1d27',border:'1px solid #3d4261',borderRadius:16,padding:'1.5rem',width:'100%',maxWidth:width,maxHeight:'85vh',overflowY:'auto'}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'1.2rem'}}>
        <h3 style={{color:'#fff',margin:0,fontSize:15,fontFamily:"'Sora',sans-serif"}}>{title}</h3>
        <button onClick={onClose} style={{background:'none',border:'none',color:'#64748b',cursor:'pointer',fontSize:22,lineHeight:1,padding:4}}>×</button>
      </div>
      {children}
    </div>
  </div>;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
export function Toast({ msg, type='ok', onClose }) {
  useEffect(()=>{ const t=setTimeout(onClose,4000); return()=>clearTimeout(t); },[onClose]);
  const [fg,bg,bord] = type==='err'?['#fca5a5','#450a0a','#991b1b']:type==='warn'?['#fcd34d','#431407','#92400e']:['#6ee7b7','#052e16','#166534'];
  return <div style={{position:'fixed',top:20,right:20,background:bg,color:fg,border:`1px solid ${bord}`,borderRadius:12,
    padding:'12px 20px',fontSize:13,fontWeight:500,zIndex:9999,maxWidth:340,boxShadow:'0 8px 32px rgba(0,0,0,.5)',lineHeight:1.5}}>
    {msg}
  </div>;
}

// ── Page header ───────────────────────────────────────────────────────────────
export function PHdr({ title, sub, right }) {
  return <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:'1.25rem'}}>
    <div>
      <h1 style={{fontFamily:"'Sora',sans-serif",fontSize:20,fontWeight:600,color:'#fff',margin:0}}>{title}</h1>
      {sub && <p style={{fontSize:12,color:'#64748b',marginTop:4,margin:0}}>{sub}</p>}
    </div>
    {right && <div style={{display:'flex',gap:'0.5rem',flexWrap:'wrap'}}>{right}</div>}
  </div>;
}

// ── Simple data table ─────────────────────────────────────────────────────────
export function DataRow({ label, value, mono }) {
  return <div style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'1px solid #1e2535',fontSize:12,gap:'1rem'}}>
    <span style={{color:'#64748b',flexShrink:0}}>{label}</span>
    <span style={{color:'#e2e8f0',fontWeight:500,textAlign:'right',fontFamily:mono?'monospace':'inherit'}}>{value}</span>
  </div>;
}

// ── Signal bar ────────────────────────────────────────────────────────────────
export function SigBar({ label, score, max=45 }) {
  const pct = Math.min(100, Math.round((score/max)*100));
  return <div style={{marginBottom:8}}>
    <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:3}}>
      <span style={{color:'#94a3b8'}}>{label}</span>
      <span style={{color:'#fbbf24',fontWeight:700}}>+{score}</span>
    </div>
    <div style={{height:5,background:'#2d3147',borderRadius:3,overflow:'hidden'}}>
      <div style={{height:'100%',background:'linear-gradient(90deg,#f59e0b,#ef4444)',borderRadius:3,width:`${pct}%`,transition:'width .5s'}}/>
    </div>
  </div>;
}
