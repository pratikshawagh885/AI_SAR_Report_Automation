// store.js — Single source of truth

const CALLBACKS = [];
function notify() { CALLBACKS.forEach(fn => fn()); }
export function subscribe(fn) { CALLBACKS.push(fn); return () => { const i = CALLBACKS.indexOf(fn); if (i>-1) CALLBACKS.splice(i,1); }; }

function loadTxns()  { try { return JSON.parse(localStorage.getItem('sar_txns')) || null; } catch { return null; } }
function saveTxns(t) { localStorage.setItem('sar_txns', JSON.stringify(t)); }
function loadSARs()  { try { return JSON.parse(localStorage.getItem('sar_sars')) || []; } catch { return []; } }
function saveSARs(s) { localStorage.setItem('sar_sars', JSON.stringify(s)); }
function loadLog()   { try { return JSON.parse(localStorage.getItem('sar_log')) || []; } catch { return []; } }
function saveLog(l)  { localStorage.setItem('sar_log', JSON.stringify(l)); }

// ── Seed: historical demo transactions (shown until real ones exist) ──────────
// These are injected ONCE for any account that has no txns yet, using a
// placeholder accountId that gets swapped to the real one at seed time.
const SEED_TEMPLATES = [
  // 2025 — older history
  { mo:8,  d:3,  amt:3200,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:8,  d:12, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:8,  d:15, amt:420,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
  { mo:8,  d:20, amt:280,   to:'AT&T Wireless',            type:'ACH Transfer',    note:'Phone bill',               dir:'out', cat:'Utilities',  risk:3  },
  { mo:9,  d:3,  amt:3200,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:9,  d:8,  amt:750,   to:'Delta Airlines',           type:'Wire Transfer',   note:'Flight to NYC',            dir:'out', cat:'Travel',     risk:9  },
  { mo:9,  d:14, amt:390,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
  { mo:9,  d:22, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:10, d:3,  amt:3200,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:10, d:10, amt:1800,  to:'Vanguard Investments',     type:'Wire Transfer',   note:'Investment contribution',  dir:'out', cat:'Investment', risk:7  },
  { mo:10, d:15, amt:460,   to:'Amazon.com',               type:'ACH Transfer',    note:'Online shopping',          dir:'out', cat:'Shopping',   risk:5  },
  { mo:10, d:22, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:11, d:3,  amt:3200,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:11, d:5,  amt:320,   to:'AT&T Wireless',            type:'ACH Transfer',    note:'Phone bill',               dir:'out', cat:'Utilities',  risk:3  },
  { mo:11, d:12, amt:550,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Thanksgiving groceries',   dir:'out', cat:'Groceries',  risk:3  },
  { mo:11, d:20, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:11, d:28, amt:900,   to:'Amazon.com',               type:'ACH Transfer',    note:'Black Friday shopping',    dir:'out', cat:'Shopping',   risk:5  },
  { mo:12, d:1,  amt:3200,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:12, d:10, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:12, d:15, amt:1400,  to:'Amazon.com',               type:'ACH Transfer',    note:'Holiday shopping',         dir:'out', cat:'Shopping',   risk:5  },
  { mo:12, d:20, amt:600,   to:'Delta Airlines',           type:'Wire Transfer',   note:'Holiday travel',           dir:'out', cat:'Travel',     risk:9  },
  { mo:12, d:25, amt:500,   to:'David Chen',               type:'Zelle',           note:'Christmas gift',           dir:'out', cat:'Transfer',   risk:5  },
  // 2026 — recent months
  { mo:1,  d:3,  amt:3400,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary (raise!)',  dir:'in',  cat:'Income',     risk:4  },
  { mo:1,  d:8,  amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:1,  d:12, amt:480,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
  { mo:1,  d:18, amt:2000,  to:'Vanguard Investments',     type:'Wire Transfer',   note:'Investment contribution',  dir:'out', cat:'Investment', risk:7  },
  { mo:1,  d:25, amt:320,   to:'AT&T Wireless',            type:'ACH Transfer',    note:'Phone bill',               dir:'out', cat:'Utilities',  risk:3  },
  { mo:2,  d:3,  amt:3400,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:2,  d:7,  amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:2,  d:14, amt:380,   to:'The Cheesecake Factory',   type:'ACH Transfer',    note:"Valentine's dinner",       dir:'out', cat:'Dining',     risk:3  },
  { mo:2,  d:20, amt:250,   to:'Spotify + Netflix Bundle', type:'ACH Transfer',    note:'Subscriptions',            dir:'out', cat:'Utilities',  risk:3  },
  { mo:2,  d:26, amt:620,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
  { mo:3,  d:3,  amt:3400,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:3,  d:10, amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:3,  d:15, amt:800,   to:'United Airlines',          type:'Wire Transfer',   note:'Spring break flight',      dir:'out', cat:'Travel',     risk:9  },
  { mo:3,  d:20, amt:2500,  to:'Vanguard Investments',     type:'Wire Transfer',   note:'Investment contribution',  dir:'out', cat:'Investment', risk:7  },
  { mo:3,  d:28, amt:410,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
  { mo:4,  d:1,  amt:3400,  to:'TechCorp Inc (Salary)',    type:'Direct Deposit',  note:'Monthly salary',           dir:'in',  cat:'Income',     risk:4  },
  { mo:4,  d:5,  amt:1100,  to:'City Apartments',          type:'ACH Transfer',    note:'Rent payment',             dir:'out', cat:'Housing',    risk:6  },
  { mo:4,  d:10, amt:500,   to:'Marcus Webb',              type:'Zelle',           note:'Shared expenses',          dir:'out', cat:'Transfer',   risk:5  },
  { mo:4,  d:15, amt:370,   to:'Whole Foods Market',       type:'ACH Transfer',    note:'Groceries',                dir:'out', cat:'Groceries',  risk:3  },
];

function buildSeedTxns(accountId, userName) {
  return SEED_TEMPLATES.map((t, i) => {
    const year = t.mo <= 7 ? 2025 : (t.mo <= 12 ? 2025 : 2026);
    const realYear = t.mo >= 1 && t.mo <= 4 ? 2026 : 2025;
    const date = new Date(realYear, t.mo - 1, t.d, 9, 0, 0);
    return {
      id: `TXN-SEED-${accountId.slice(-6)}-${i}`,
      accountId,
      userName,
      amount: t.amt,
      type: t.type,
      country: 'USA',
      counterparty: t.to,
      toAccount: '',
      riskScore: t.risk,
      signals: {},
      status: 'cleared',
      adminAction: 'approved',
      adminBy: 'System',
      adminAt: date.toISOString(),
      time: date.toISOString(),
      notes: t.note,
      direction: t.dir,
      category: t.cat,
      fromUser: true,
      isSeeded: true,
    };
  });
}

// ── Initialise TRANSACTIONS (load from storage or empty) ─────────────────────
let TRANSACTIONS = loadTxns() || [];
let SARS         = loadSARs();
let AUDIT_LOG    = loadLog();

// ── ML risk scoring ──────────────────────────────────────────────────────────
const HIGH_RISK_COUNTRIES = new Set(['Cayman Islands','Panama','Belize','BVI','Vanuatu','Seychelles','Marshall Islands']);
export function mlScore(txn) {
  const signals = {}; let score = 0;
  const ratio = txn.amount / 300;
  if (ratio > 5)   { const s = Math.min(40, Math.round((ratio-5)*4)); signals[`Amount ${ratio.toFixed(1)}x avg`] = s; score += s; }
  if (txn.amount > 9000 && txn.amount < 10000) { signals['Sub-threshold structuring'] = 22; score += 22; }
  if (HIGH_RISK_COUNTRIES.has(txn.country))    { signals['High-risk jurisdiction']    = 31; score += 31; }
  const h = new Date(txn.time||Date.now()).getHours();
  if (h < 5 || h > 22) { signals['Off-hours transaction'] = 8; score += 8; }
  return { score: Math.min(99, Math.max(2, score)), signals };
}

// ── DB API ───────────────────────────────────────────────────────────────────
export const DB = {
  transactions:     ()  => [...TRANSACTIONS],
  userTransactions: (accountId) => TRANSACTIONS.filter(t => t.accountId === accountId),
  allUserTxns:      ()  => TRANSACTIONS.filter(t => t.fromUser === true),
  sars:             ()  => [...SARS],
  auditLog:         ()  => [...AUDIT_LOG],

  getBalance(accountId) {
    const users = (() => { try { return JSON.parse(localStorage.getItem('sar_users'))||[]; } catch { return []; } })();
    const u = users.find(x => x.accountId === accountId);
    return u?.balance ?? 10000;
  },

  updateBalance(accountId, newBal) {
    const users = (() => { try { return JSON.parse(localStorage.getItem('sar_users'))||[]; } catch { return []; } })();
    const updated = users.map(u => u.accountId === accountId ? {...u, balance: newBal} : u);
    localStorage.setItem('sar_users', JSON.stringify(updated));
  },

  // Called right after a new user account is created — seeds historical data
  seedUserTransactions(accountId, userName) {
    const already = TRANSACTIONS.some(t => t.accountId === accountId);
    if (already) return;
    const seeded = buildSeedTxns(accountId, userName);
    TRANSACTIONS = [...seeded, ...TRANSACTIONS];
    saveTxns(TRANSACTIONS);
    notify();
  },

  // User submits a transfer
  transferMoney({ fromAccountId, toName, toAccount, amount, type, note, userName }) {
    const bal = this.getBalance(fromAccountId);
    if (bal < amount) throw new Error(`Insufficient balance. Available: $${bal.toFixed(2)}`);
    const { score, signals } = mlScore({ amount, country:'USA', time: new Date().toISOString() });
    const txn = {
      id: 'TXN-' + Date.now(),
      accountId: fromAccountId,
      userName,
      amount,
      type: type || 'ACH Transfer',
      country: 'USA',
      counterparty: toName || toAccount,
      toAccount,
      riskScore: score,
      signals,
      status: 'pending_review',
      adminAction: null,
      time: new Date().toISOString(),
      notes: note || '',
      direction: 'out',
      category: 'Transfer',
      fromUser: true,
    };
    this.updateBalance(fromAccountId, bal - amount);
    TRANSACTIONS.unshift(txn);
    saveTxns(TRANSACTIONS);
    this._log('Transfer Submitted', `${txn.id}: ${userName} → ${toName||toAccount} $${amount.toLocaleString()} · Risk: ${score}`, userName);
    notify();
    return txn;
  },

  approveTransaction(txnId, adminName) {
    TRANSACTIONS = TRANSACTIONS.map(t => t.id===txnId ? {...t, status:'cleared', adminAction:'approved', adminBy:adminName, adminAt:new Date().toISOString()} : t);
    saveTxns(TRANSACTIONS);
    this._log('Transaction Approved', `${txnId} approved by ${adminName}`, adminName);
    notify();
  },

  rejectTransaction(txnId, reason, adminName) {
    const txn = TRANSACTIONS.find(t => t.id===txnId);
    if (txn) {
      const bal = this.getBalance(txn.accountId);
      this.updateBalance(txn.accountId, bal + txn.amount);
    }
    TRANSACTIONS = TRANSACTIONS.map(t => t.id===txnId ? {...t, status:'rejected', adminAction:'rejected', adminBy:adminName, adminAt:new Date().toISOString(), rejectionReason:reason} : t);
    saveTxns(TRANSACTIONS);
    this._log('Transaction Rejected', `${txnId} rejected by ${adminName}: "${reason}" — refunded`, adminName);
    notify();
  },

  flagAsSAR(txnId, adminName) {
    const txn = TRANSACTIONS.find(t => t.id===txnId);
    if (!txn) return null;
    const sarId = 'SAR-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random()*9000+1000));
    const sar = {
      id: sarId, accountId: txn.accountId, txnIds:[txnId],
      amount: txn.amount, riskScore: txn.riskScore, type: txn.type,
      status: 'pending_review', jurisdiction:'FinCEN',
      createdBy: adminName, createdAt: new Date().toISOString(),
      narrative: `On ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}, account ${txn.accountId} (${txn.userName}) submitted a ${txn.type} of $${txn.amount.toLocaleString()} to ${txn.counterparty}. Risk score: ${txn.riskScore}/100. ${txn.notes?'User note: '+txn.notes+'.':''} Signals detected: ${Object.keys(txn.signals||{}).join(', ')||'None'}.`,
      signals: txn.signals, approvedBy:null, approvedAt:null, rejectedBy:null, rejectionReason:null, filedBy:null, filedAt:null, blockchainHash:null,
    };
    TRANSACTIONS = TRANSACTIONS.map(t => t.id===txnId ? {...t, status:'flagged', adminAction:'sar', sarId} : t);
    SARS.unshift(sar);
    saveTxns(TRANSACTIONS); saveSARs(SARS);
    this._log('SAR Created', `${sarId} from ${txnId} by ${adminName}`, adminName);
    notify();
    return sar;
  },

  approveSAR(sarId, officer) {
    SARS = SARS.map(s => s.id===sarId ? {...s, status:'approved', approvedBy:officer, approvedAt:new Date().toISOString()} : s);
    saveSARs(SARS); this._log('SAR Approved', `${sarId} by ${officer}`, officer); notify();
  },

  rejectSAR(sarId, reason, officer) {
    SARS = SARS.map(s => s.id===sarId ? {...s, status:'rejected', rejectedBy:officer, rejectionReason:reason} : s);
    saveSARs(SARS); this._log('SAR Rejected', `${sarId}: "${reason}"`, officer); notify();
  },

  fileSAR(sarId, officer) {
    const hash = '0x'+Array.from({length:24},()=>'0123456789abcdef'[Math.floor(Math.random()*16)]).join('');
    SARS = SARS.map(s => s.id===sarId ? {...s, status:'filed', blockchainHash:hash, filedBy:officer, filedAt:new Date().toISOString()} : s);
    saveSARs(SARS); this._log('SAR Filed On-Chain', `${sarId} hash:${hash.slice(0,12)}… by ${officer}`, officer); notify(); return hash;
  },

  _log(action, detail, user) {
    AUDIT_LOG.unshift({ action, detail, user, ts: new Date().toISOString() });
    saveLog(AUDIT_LOG);
  },
};
