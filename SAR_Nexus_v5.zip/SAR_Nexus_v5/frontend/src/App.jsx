import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import UserDashboard from './pages/UserDashboard';
import TransferPage from './pages/TransferPage';

function AdminGuard({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace/>;
  if (user.role === 'user') return <Navigate to="/user-dashboard" replace/>;
  return children;
}

function UserGuard({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace/>;
  if (user.role !== 'user') return <Navigate to="/admin" replace/>;
  return children;
}

function RootRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace/>;
  return <Navigate to={user.role === 'user' ? '/user-dashboard' : '/admin'} replace/>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login"          element={<Login/>}/>
          <Route path="/"               element={<RootRedirect/>}/>
          <Route path="/admin"          element={<AdminGuard><AdminDashboard/></AdminGuard>}/>
          <Route path="/user-dashboard" element={<UserGuard><UserDashboard/></UserGuard>}/>
          <Route path="/transfer"       element={<UserGuard><TransferPage/></UserGuard>}/>
          <Route path="*"               element={<RootRedirect/>}/>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
