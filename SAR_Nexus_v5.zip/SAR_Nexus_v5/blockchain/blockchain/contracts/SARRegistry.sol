// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/// @title SARRegistry — Immutable Suspicious Activity Report Registry
/// @notice Records SAR hashes on-chain for tamper-proof audit trail
contract SARRegistry {

    // ── Structs ────────────────────────────────────────────────────────────
    struct SARRecord {
        bytes32  contentHash;    // SHA-256 of the SAR document
        string   ipfsCid;        // IPFS CID of the full document
        address  filedBy;        // Compliance officer's wallet
        uint256  timestamp;      // Block timestamp
        string   sarId;          // Off-chain reference ID (e.g. SAR-2024-0089)
        string   jurisdiction;   // FinCEN / FCA / RBI
        bool     exists;
    }

    struct WhistleblowerTip {
        bytes32  contentHash;
        uint256  timestamp;
        bool     exists;
    }

    // ── State ───────────────────────────────────────────────────────────────
    address public owner;
    mapping(bytes32 => SARRecord)        public sars;          // hash → record
    mapping(string  => bytes32)          public sarIdToHash;   // sarId → hash
    mapping(bytes32 => WhistleblowerTip) public tips;

    bytes32[] public allHashes;    // ordered list for enumeration
    uint256   public totalFiled;

    // ── Events ──────────────────────────────────────────────────────────────
    event SARFiled(bytes32 indexed contentHash, string sarId, address indexed filedBy, uint256 timestamp);
    event SARVerified(bytes32 indexed contentHash, bool valid);
    event TipSubmitted(bytes32 indexed tipHash, uint256 timestamp);

    // ── Access control ──────────────────────────────────────────────────────
    mapping(address => bool) public authorizedFilers;

    modifier onlyAuthorized() {
        require(authorizedFilers[msg.sender] || msg.sender == owner, "Not authorized");
        _;
    }
    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner");
        _;
    }

    constructor() {
        owner = msg.sender;
        authorizedFilers[msg.sender] = true;
    }

    // ── Functions ────────────────────────────────────────────────────────────

    /// @notice Authorize a compliance officer wallet to file SARs
    function addFiler(address filer) external onlyOwner {
        authorizedFilers[filer] = true;
    }

    /// @notice Remove a filer's authorization
    function removeFiler(address filer) external onlyOwner {
        authorizedFilers[filer] = false;
    }

    /// @notice File a SAR — stores content hash immutably
    /// @param contentHash  SHA-256 hash of the SAR document
    /// @param ipfsCid      IPFS CID where the full document is stored
    /// @param sarId        Human-readable SAR identifier
    /// @param jurisdiction Regulatory jurisdiction code
    function fileSAR(
        bytes32       contentHash,
        string calldata ipfsCid,
        string calldata sarId,
        string calldata jurisdiction
    ) external onlyAuthorized returns (bool) {
        require(!sars[contentHash].exists,  "SAR already filed");
        require(bytes(sarId).length > 0,    "SAR ID required");

        sars[contentHash] = SARRecord({
            contentHash:  contentHash,
            ipfsCid:      ipfsCid,
            filedBy:      msg.sender,
            timestamp:    block.timestamp,
            sarId:        sarId,
            jurisdiction: jurisdiction,
            exists:       true
        });

        sarIdToHash[sarId] = contentHash;
        allHashes.push(contentHash);
        totalFiled++;

        emit SARFiled(contentHash, sarId, msg.sender, block.timestamp);
        return true;
    }

    /// @notice Verify a SAR exists on-chain
    function verifySAR(bytes32 contentHash) external view returns (bool valid, SARRecord memory record) {
        record = sars[contentHash];
        valid  = record.exists;
    }

    /// @notice Look up by human-readable SAR ID
    function getSARByID(string calldata sarId) external view returns (SARRecord memory) {
        bytes32 hash = sarIdToHash[sarId];
        require(sars[hash].exists, "SAR not found");
        return sars[hash];
    }

    /// @notice Get all filed SAR hashes (paginated)
    function getHashes(uint256 from, uint256 count) external view returns (bytes32[] memory) {
        uint256 end = from + count > allHashes.length ? allHashes.length : from + count;
        bytes32[] memory result = new bytes32[](end - from);
        for (uint256 i = from; i < end; i++) result[i - from] = allHashes[i];
        return result;
    }

    /// @notice Submit an anonymous whistleblower tip hash
    function submitTip(bytes32 tipHash) external {
        require(!tips[tipHash].exists, "Tip already recorded");
        tips[tipHash] = WhistleblowerTip({ contentHash: tipHash, timestamp: block.timestamp, exists: true });
        emit TipSubmitted(tipHash, block.timestamp);
    }

    /// @notice Verify a whistleblower tip
    function verifyTip(bytes32 tipHash) external view returns (bool, uint256) {
        WhistleblowerTip memory t = tips[tipHash];
        return (t.exists, t.timestamp);
    }
}
