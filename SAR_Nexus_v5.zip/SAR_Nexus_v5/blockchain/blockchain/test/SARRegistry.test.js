const { expect } = require('chai');
const { ethers }  = require('hardhat');

describe('SARRegistry', function () {
  let registry, owner, filer, other;

  beforeEach(async () => {
    [owner, filer, other] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory('SARRegistry');
    registry = await Factory.deploy();
    await registry.waitForDeployment();
  });

  it('deploys with owner as authorized filer', async () => {
    expect(await registry.authorizedFilers(owner.address)).to.be.true;
  });

  it('allows owner to add filer', async () => {
    await registry.addFiler(filer.address);
    expect(await registry.authorizedFilers(filer.address)).to.be.true;
  });

  it('files a SAR and emits event', async () => {
    const hash = ethers.id('test-sar-content');
    const tx   = await registry.fileSAR(hash, 'ipfs://Qm...', 'SAR-2024-0001', 'FinCEN');
    await expect(tx).to.emit(registry, 'SARFiled').withArgs(hash, 'SAR-2024-0001', owner.address, anyValue);
    expect(await registry.totalFiled()).to.equal(1);
  });

  it('verifies a filed SAR', async () => {
    const hash = ethers.id('test-content-2');
    await registry.fileSAR(hash, 'ipfs://Qm2', 'SAR-2024-0002', 'FCA');
    const [valid] = await registry.verifySAR(hash);
    expect(valid).to.be.true;
  });

  it('rejects duplicate SAR filing', async () => {
    const hash = ethers.id('duplicate');
    await registry.fileSAR(hash, 'ipfs://Qm3', 'SAR-2024-0003', 'FinCEN');
    await expect(registry.fileSAR(hash, 'ipfs://Qm3', 'SAR-2024-0003', 'FinCEN'))
      .to.be.revertedWith('SAR already filed');
  });

  it('rejects unauthorized filer', async () => {
    const hash = ethers.id('unauth');
    await expect(registry.connect(other).fileSAR(hash, 'ipfs://Qm4', 'SAR-X', 'FinCEN'))
      .to.be.revertedWith('Not authorized');
  });

  it('accepts whistleblower tip', async () => {
    const tipHash = ethers.id('anonymous-tip');
    const tx = await registry.submitTip(tipHash);
    await expect(tx).to.emit(registry, 'TipSubmitted');
    const [exists] = await registry.verifyTip(tipHash);
    expect(exists).to.be.true;
  });
});

function anyValue() { return true; }
