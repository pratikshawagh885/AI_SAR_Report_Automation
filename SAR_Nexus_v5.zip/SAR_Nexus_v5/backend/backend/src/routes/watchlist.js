const express = require('express');
const router  = express.Router();

const WATCHLIST = [
  { accountId:'ACC-4421', accountName:'Phantom Corp LLC',  riskScore:94, trend:'rising',  predictedSARDays:7,  watchedDays:3  },
  { accountId:'ACC-8821', accountName:'John D. (Personal)',riskScore:88, trend:'rising',  predictedSARDays:14, watchedDays:5  },
  { accountId:'ACC-2291', accountName:'Global Trade Inc',  riskScore:72, trend:'stable',  predictedSARDays:21, watchedDays:12 },
  { accountId:'ACC-7832', accountName:'Swift Remit Ltd',   riskScore:65, trend:'falling', predictedSARDays:30, watchedDays:18 },
];

router.get('/',     (req, res) => res.json(WATCHLIST));
router.post('/',    (req, res) => { WATCHLIST.unshift(req.body); res.status(201).json(req.body); });
router.delete('/:id', (req, res) => {
  const i = WATCHLIST.findIndex(w => w.accountId === req.params.id);
  if (i > -1) WATCHLIST.splice(i, 1);
  res.json({ success: true });
});

module.exports = router;
