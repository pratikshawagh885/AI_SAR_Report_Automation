const express = require('express');
const router  = express.Router();

const TRANSACTIONS = Array.from({ length: 20 }, (_, i) => ({
  id: `TXN-${9900 - i}`,
  accountId: `ACC-${1000 + Math.floor(Math.random() * 8999)}`,
  amount: Math.floor(Math.random() * 200000) + 1000,
  type: ['Wire','ACH','Cash','SWIFT','Crypto'][i % 5],
  riskScore: Math.floor(Math.random() * 100),
  status: ['flagged','review','cleared'][i % 3],
  jurisdiction: ['USA','UK','CAYMAN','INDIA','GERMANY'][i % 5],
  createdAt: new Date(Date.now() - i * 3600000).toISOString(),
}));

router.get('/', (req, res) => {
  const { status, minRisk, page = 1, limit = 20 } = req.query;
  let data = [...TRANSACTIONS];
  if (status)  data = data.filter(t => t.status === status);
  if (minRisk) data = data.filter(t => t.riskScore >= Number(minRisk));
  res.json({ txns: data.slice((page-1)*limit, page*limit), total: data.length });
});

router.get('/:id', (req, res) => {
  const t = TRANSACTIONS.find(t => t.id === req.params.id);
  t ? res.json(t) : res.status(404).json({ error: 'Not found' });
});

router.post('/', (req, res) => {
  const txn = { id: 'TXN-' + Date.now(), ...req.body, riskScore: Math.floor(Math.random()*100), createdAt: new Date().toISOString() };
  TRANSACTIONS.unshift(txn);
  res.status(201).json(txn);
});

module.exports = router;
