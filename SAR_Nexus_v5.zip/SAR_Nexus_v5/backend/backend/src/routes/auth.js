const express = require('express');
const jwt     = require('jsonwebtoken');
const router  = express.Router();
const SECRET  = process.env.JWT_SECRET || 'dev_secret_123';

const DEMO_USERS = [
  { id:'1', name:'Sarah K.', email:'analyst@sar.io', password:'demo123', role:'analyst' },
  { id:'2', name:'Mike R.',  email:'officer@sar.io', password:'demo123', role:'officer' },
  { id:'3', name:'Admin',    email:'admin@sar.io',   password:'demo123', role:'admin'   },
  { id:'4', name:'James T.', email:'legal@sar.io',   password:'demo123', role:'legal'   },
];

const signToken = (u) => jwt.sign({ id:u.id, email:u.email, role:u.role, name:u.name }, SECRET, { expiresIn:'7d' });

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = DEMO_USERS.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ token: signToken(user), user: { id:user.id, name:user.name, email:user.email, role:user.role } });
});

router.post('/register', (req, res) => {
  const { name, email, password, role='analyst' } = req.body;
  const u = { id: Date.now().toString(), name, email, password, role };
  DEMO_USERS.push(u);
  res.status(201).json({ token: signToken(u), user: { id:u.id, name, email, role } });
});

router.get('/me', (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const user  = jwt.verify(token, SECRET);
    res.json(user);
  } catch { res.status(401).json({ error: 'Invalid token' }); }
});

module.exports = router;
