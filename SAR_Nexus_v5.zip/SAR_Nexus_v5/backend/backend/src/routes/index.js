// ═══════════════════════════════════════════════════
//  ROUTES — collected in one file for clarity
//  In production split into separate files per route
// ═══════════════════════════════════════════════════
const express = require('express');
const jwt     = require('jsonwebtoken');
const crypto  = require('crypto');
const axios   = require('axios');
const { User, Transaction, SAR, Watchlist, BlockchainRecord, Whistleblower } = require('../models');
const auth    = require('../middleware/auth');
const { requireRole } = require('../middleware/auth');

const SECRET = process.env.JWT_SECRET || 'dev_secret';
const signToken = (u) => jwt.sign({ id: u._id, email: u.email, role: u.role, name: u.name }, SECRET, { expiresIn: '7d' });

// ── AUTH ─────────────────────────────────────────────────────────────────────
const authRouter = express.Router();
authRouter.post('/register', async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json({ token: signToken(user), user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
authRouter.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ error: 'Invalid credentials' });
    res.json({ token: signToken(user), user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
authRouter.get('/me', auth, async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  res.json(user);
});

// ── TRANSACTIONS ─────────────────────────────────────────────────────────────
const txnRouter = express.Router();
txnRouter.use(auth);
txnRouter.get('/', async (req, res) => {
  const { page = 1, limit = 20, status, minRisk } = req.query;
  const filter = {};
  if (status)  filter.status = status;
  if (minRisk) filter.riskScore = { $gte: Number(minRisk) };
  const txns = await Transaction.find(filter).sort({ createdAt: -1 }).limit(limit).skip((page-1)*limit);
  const total = await Transaction.countDocuments(filter);
  res.json({ txns, total, pages: Math.ceil(total/limit) });
});
txnRouter.post('/', requireRole('admin'), async (req, res) => {
  try {
    // Call ML service for risk scoring
    let mlResult = { riskScore: 50, signals: {} };
    try {
      const { data } = await axios.post(`${process.env.ML_SERVICE_URL || 'http://localhost:8000'}/predict`, req.body, { timeout: 5000 });
      mlResult = data;
    } catch { /* ML service unavailable, use defaults */ }
    const txn = await Transaction.create({ ...req.body, riskScore: mlResult.riskScore, mlSignals: mlResult.signals });
    if (txn.riskScore >= 80) txn.status = 'flagged';
    await txn.save();
    res.status(201).json(txn);
  } catch (e) { res.status(400).json({ error: e.message }); }
});
txnRouter.get('/:id', async (req, res) => {
  const txn = await Transaction.findById(req.params.id);
  txn ? res.json(txn) : res.status(404).json({ error: 'Not found' });
});

// ── SAR REPORTS ───────────────────────────────────────────────────────────────
const sarRouter = express.Router();
sarRouter.use(auth);
sarRouter.get('/', async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};
  const sars = await SAR.find(filter).sort({ createdAt: -1 }).populate('analystId', 'name');
  res.json(sars);
});
sarRouter.post('/', requireRole('analyst','officer','admin'), async (req, res) => {
  try {
    // Auto-generate narrative via ML service
    let narrative = req.body.narrative || '';
    if (!narrative) {
      try {
        const { data } = await axios.post(`${process.env.ML_SERVICE_URL || 'http://localhost:8000'}/generate-narrative`, req.body, { timeout: 10000 });
        narrative = data.narrative;
      } catch { narrative = `[AI narrative pending — ML service unavailable]\n\nAccount ${req.body.accountId} flagged for suspicious activity on ${new Date().toLocaleDateString()}.`; }
    }
    const sarId = 'SAR-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random()*9999)).padStart(4,'0');
    const sar = await SAR.create({ ...req.body, sarId, narrative, analystId: req.user.id });
    res.status(201).json(sar);
  } catch (e) { res.status(400).json({ error: e.message }); }
});
sarRouter.get('/:id', async (req, res) => {
  const sar = await SAR.findOne({ sarId: req.params.id }).populate('analystId officerId', 'name email role');
  sar ? res.json(sar) : res.status(404).json({ error: 'Not found' });
});
sarRouter.patch('/:id/approve', requireRole('officer','admin'), async (req, res) => {
  const sar = await SAR.findOneAndUpdate({ sarId: req.params.id }, { status: 'approved', officerId: req.user.id, approvedAt: new Date() }, { new: true });
  sar ? res.json(sar) : res.status(404).json({ error: 'Not found' });
});
sarRouter.patch('/:id/reject', requireRole('officer','admin'), async (req, res) => {
  const sar = await SAR.findOneAndUpdate({ sarId: req.params.id }, { status: 'rejected', rejectionReason: req.body.reason }, { new: true });
  sar ? res.json(sar) : res.status(404).json({ error: 'Not found' });
});

// ── ANALYTICS ────────────────────────────────────────────────────────────────
const analyticsRouter = express.Router();
analyticsRouter.use(auth);
analyticsRouter.get('/summary', async (req, res) => {
  const [totalTxns, flagged, sarsFiled, sarsPending] = await Promise.all([
    Transaction.countDocuments(),
    Transaction.countDocuments({ status: 'flagged' }),
    SAR.countDocuments({ status: 'filed' }),
    SAR.countDocuments({ status: 'pending_review' }),
  ]);
  res.json({ totalTxns, flagged, sarsFiled, sarsPending });
});
analyticsRouter.get('/monthly', async (req, res) => {
  const data = await SAR.aggregate([
    { $group: { _id: { $month: '$createdAt' }, count: { $sum: 1 }, filed: { $sum: { $cond: [{ $eq: ['$status','filed'] }, 1, 0] } } } },
    { $sort: { '_id': 1 } },
  ]);
  res.json(data);
});

// ── WATCHLIST ────────────────────────────────────────────────────────────────
const watchlistRouter = express.Router();
watchlistRouter.use(auth);
watchlistRouter.get('/', async (req, res) => {
  const list = await Watchlist.find({ active: true }).sort({ riskScore: -1 });
  res.json(list);
});
watchlistRouter.post('/', requireRole('analyst','officer','admin'), async (req, res) => {
  try {
    const entry = await Watchlist.create(req.body);
    res.status(201).json(entry);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// ── BLOCKCHAIN ───────────────────────────────────────────────────────────────
const blockchainRouter = express.Router();
blockchainRouter.use(auth);
blockchainRouter.get('/records', async (req, res) => {
  const records = await BlockchainRecord.find().sort({ timestamp: -1 }).limit(20).populate('filedBy', 'name');
  res.json(records);
});
blockchainRouter.post('/file/:sarId', requireRole('officer','admin'), async (req, res) => {
  try {
    const sar = await SAR.findOne({ sarId: req.params.sarId });
    if (!sar) return res.status(404).json({ error: 'SAR not found' });
    if (sar.status !== 'approved') return res.status(400).json({ error: 'SAR must be approved before filing' });

    // In production: call ethers.js to write to smart contract
    // Mock blockchain filing:
    const mockTxHash = '0x' + crypto.randomBytes(32).toString('hex');
    const mockBlock  = 19000000 + Math.floor(Math.random() * 500000);

    await SAR.findOneAndUpdate({ sarId: req.params.sarId }, {
      status: 'filed', blockchainHash: mockTxHash, blockchainBlock: mockBlock, filedAt: new Date(),
    });
    const record = await BlockchainRecord.create({
      sarId: req.params.sarId, txHash: mockTxHash, blockNumber: mockBlock,
      gasUsed: '0.002 ETH', filedBy: req.user.id,
    });
    res.json({ success: true, txHash: mockTxHash, blockNumber: mockBlock, record });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
blockchainRouter.get('/verify/:hash', async (req, res) => {
  const record = await BlockchainRecord.findOne({ txHash: new RegExp(req.params.hash, 'i') });
  res.json({ verified: !!record, record });
});

// ── WHISTLEBLOWER ────────────────────────────────────────────────────────────
const whistleblowerRouter = express.Router();
whistleblowerRouter.post('/submit', async (req, res) => {
  try {
    const { category, content } = req.body;
    const contentHash    = crypto.createHash('sha256').update(content || '').digest('hex');
    // AES-256 mock encryption (in prod use a proper key management service)
    const encryptedContent = Buffer.from(content || '').toString('base64');
    const refId          = 'WB-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    const blockchainHash = '0x' + crypto.randomBytes(32).toString('hex'); // mock
    const tip = await Whistleblower.create({ refId, category, encryptedContent, contentHash, blockchainHash });
    res.status(201).json({ refId, blockchainHash, message: 'Submission received and encrypted' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
whistleblowerRouter.get('/status/:refId', async (req, res) => {
  const tip = await Whistleblower.findOne({ refId: req.params.refId }).select('-encryptedContent');
  tip ? res.json(tip) : res.status(404).json({ error: 'Not found' });
});

module.exports = { authRouter, txnRouter, sarRouter, analyticsRouter, watchlistRouter, blockchainRouter, whistleblowerRouter };
