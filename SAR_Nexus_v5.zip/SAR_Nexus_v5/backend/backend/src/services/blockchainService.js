// backend/src/services/blockchainService.js
const { ethers } = require('ethers');
const crypto     = require('crypto');

const ABI = [
  'function fileSAR(bytes32 contentHash, string ipfsCid, string sarId, string jurisdiction) returns (bool)',
  'function verifySAR(bytes32 contentHash) view returns (bool valid, tuple(bytes32,string,address,uint256,string,string,bool) record)',
  'function getSARByID(string sarId) view returns (tuple(bytes32,string,address,uint256,string,string,bool))',
  'function submitTip(bytes32 tipHash)',
  'event SARFiled(bytes32 indexed contentHash, string sarId, address indexed filedBy, uint256 timestamp)',
];

class BlockchainService {
  constructor() {
    this.provider = new ethers.JsonRpcProvider(process.env.ETHEREUM_RPC_URL || 'http://localhost:8545');
    this.signer   = this.provider.getSigner ? null : null; // Set on init
    this.contract = null;
    this._init();
  }

  async _init() {
    try {
      if (process.env.PRIVATE_KEY && process.env.CONTRACT_ADDRESS) {
        const wallet   = new ethers.Wallet(process.env.PRIVATE_KEY, this.provider);
        this.contract  = new ethers.Contract(process.env.CONTRACT_ADDRESS, ABI, wallet);
        console.log('✅ Blockchain service connected');
      }
    } catch (e) { console.warn('⚠ Blockchain service unavailable:', e.message); }
  }

  sha256(content) {
    return '0x' + crypto.createHash('sha256').update(JSON.stringify(content)).digest('hex');
  }

  async fileSAR(sarDocument, ipfsCid = '') {
    if (!this.contract) return { mock: true, txHash: '0x' + crypto.randomBytes(32).toString('hex') };
    const contentHash = this.sha256(sarDocument);
    const tx   = await this.contract.fileSAR(contentHash, ipfsCid, sarDocument.sarId, sarDocument.jurisdiction || 'FinCEN');
    const receipt = await tx.wait();
    return { txHash: receipt.hash, blockNumber: receipt.blockNumber, contentHash };
  }

  async verifySAR(contentHash) {
    if (!this.contract) return { verified: false, mock: true };
    const [valid, record] = await this.contract.verifySAR(contentHash);
    return { verified: valid, record };
  }

  async submitTip(content) {
    const tipHash = this.sha256(content + Date.now());
    if (!this.contract) return { tipHash, mock: true };
    const tx = await this.contract.submitTip(tipHash);
    const receipt = await tx.wait();
    return { tipHash, txHash: receipt.hash, blockNumber: receipt.blockNumber };
  }
}

module.exports = new BlockchainService();
